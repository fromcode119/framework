/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#FF5F1F', // Safety Orange
          dark: '#E6551B',
        },
        obsidian: {
          DEFAULT: '#0B0B0B',
          light: '#1A1A1A',
          dark: '#000000',
        },
        accent: {
          DEFAULT: '#10b981', // Success Green (Keep for trust/ROI metrics)
          dark: '#059669',
        },
        neutral: {
          DEFAULT: '#e2e8f0', // Light gray for text on dark
          dark: '#94a3b8',
        },
        alert: {
          DEFAULT: '#ef4444', // Red for "Zombie" comparisons
          dark: '#b91c1c',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}

