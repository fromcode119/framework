# Snapbilt Theme Integration Roadmap

This checklist tracks the conversion of the static Snapbilt site into a dynamic Fromcode theme.

## Phase 1: Theme Infrastructure & Manifest
- [x] **Create Theme Directory**: Mirror the prebuilt theme structure into `framework/Source/themes/snapbilt-theme`.
- [x] **Manifest Creation**: Create `theme.json` with slug `snapbilt`, version `1.0.0`, and industrial metadata.
- [x] **Build Pipeline Alignment**: Update `vite.config.js` in Snapbilt to output bundle/CSS directly to the framework's `ui` folder.
- [x] **Asset Path Hardening**: Ensure all images and video references (`/video-website.webm`, etc.) are served via the framework's asset routes.

## Phase 2: Dynamic Component Wiring (The "Hook-up")
- [x] **Global Variables**: Replace `CONTACT_LINKS` and `CONFIG` in `src/config/constants.js` with `useTheme().variables`.
- [x] **Navigation**: Refactor `Navbar.jsx` to fetch menu items from the `navigation` collection.
- [x] **Portfolio Sync**: Refactor `Examples.jsx` to fetch the 3 case studies from the `posts` collection instead of static imports.
- [x] **Route Mapping**: Replace `react-router-dom` usage with framework-compatible dynamic routing.

## Phase 3: CMS Block Registration
- [x] **Define Blocks**: Integrated components as registered layout parts.
    - [x] `HeroSection`
    - [x] `IndustrialPricing`
- [x] **Content Renderer**: Implemented `AppContent` in `App.jsx` with dynamic routing.

## Phase 4: Data Seeding & Migration
- [x] **Initial Seed**: Configured `theme.json` with recommended variables and layout definitions.
- [x] **Media Import**: Successfully copied video assets to the framework's theme UI directory.

## Phase 5: Integration & Verification
- [ ] **Theme Activation**: Enable the theme via the Fromcode Admin panel.
- [ ] **Live Preview**: Verify that content edits in the Admin (e.g., changing the Hero text) reflect instantly.
- [ ] **Performance Audit**: Confirm the `<1s` load speed guarantee holds after framework overhead.

---
*Created on 2026-02-07*
