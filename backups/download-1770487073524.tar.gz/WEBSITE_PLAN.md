# SnapBilt Website — Build Plan & Site Architecture

**Internal Planning Document for SnapBilt Website Development**

---

## 🚨 MASTER RULE: MOBILE-FIRST ALWAYS

**90%+ of contractor searches happen on mobile devices. Every design decision, every feature, every layout MUST be optimized for mobile first, then scaled up to desktop.**

### Mobile-First Checklist:

- ✅ All CTAs must be thumb-accessible (bottom 1/3 of screen)
- ✅ Text must be readable without zooming (16px minimum)
- ✅ Containers must fit within viewport (no horizontal scroll)
- ✅ Touch targets minimum 44x44px
- ✅ Test on iPhone 14, 14 Pro Max, and Android devices before desktop
- ✅ Speed target <1s on 4G, <3s on 3G

---

## 🎯 Website Objectives

1. **Bridge the Legitimacy Gap** — Show established contractors (570+ reviews) that their current website is costing them Whale Leads (£50k+).
2. **Convert Established Contractors** — Show instant credibility and ROI within 10 seconds.
3. **Demonstrate Product Quality** — Live examples and 3rd-party speed metrics that prove our 72-hour build capability.
4. **Enable Zero-Friction Sales** — WhatsApp/SMS-first contact, no calendar bookings.
5. **Build Trust Through Speed** — Sub-1s load times (practice what we preach).

---

## 📄 Page Structure & Content

### **1. Homepage** (`/`)

**Purpose:** Hook contractors in 10 seconds. Show the problem → solution → proof.

#### Sections:

**Hero Section**

- **Headline:** "Stop Losing £50k+ Leads to Contractors with Better Websites"
- **Sub-headline:** "72-Hour Precision Websites for Elite UK Roofers. No Meetings. No Revisions. Just Results."
- **CTA:** "See Your New Site (Built in 72 Hours)" → Leads to demo request
- **Visual:** Split-screen comparison — "Zombie Site" vs. "SnapBilt Site" (Page Speed, Trust Signals)

**The Problem Section** ("The Directory Tax")

- Stat callouts:
  - "Checkatrade sends YOUR lead to 5 competitors"
  - "£15k re-roofing jobs go to whoever has the best website"
  - "Traditional agencies: 8 weeks, £5k+, endless calls"
- Visual: Icon grid showing the "lead dilution" funnel

**The Solution Section** ("The 72-Hour Build")

- **3-Column Feature Grid:**
  1. **Authority-First Design** — Built for trust (reviews, certifications, project galleries)
  2. **Speed Optimized** — Under 1-second load (Core Web Vitals badge)
  3. **Zero Friction** — We build the draft FIRST using your existing Checkatrade data
- **Process Timeline:**
  - Day 0: We build your demo site
  - Day 1: You receive Loom video comparison
  - Day 2: You click "Claim Now" (WhatsApp trigger)
  - Day 3: Site goes live under your domain

**Live Examples Section** ("See the Difference")

- **Interactive Demo Grid** (3-4 cards):
  - Each card shows a subdomain preview (e.g., `johnsroofing.snapbilt.co.uk`)
  - Hover → Shows Page Speed score + Review count
  - Click → Opens subdomain in new tab
- **CTA:** "Want to see YOURS? Let's build it."

**Pricing Section** ("One Lead Pays for Everything")

- **Scarcity Engine:** "Only 3 Build Slots Available This Week" (Dynamic-style urgency banner).
- **Pricing Card:**
  - £2,500 - £4,000 (One-time build)
  - £30/mo (Optional managed hosting)
  - **ROI Calculator:** "A single £15k re-roofing job = 6x ROI"
- **The "Legitimacy Check" (Agency vs SnapBilt):**
  - Side-by-side comparison of SnapBilt vs. £10k Branding Agencies vs. DIY builders.
- **What's Included:**
  - ✅ Mobile-first design (90%+ of searches)
  - ✅ Auto-imported reviews from Checkatrade/Google
  - ✅ Project gallery (we pull from your socials)
  - ✅ Contact forms + WhatsApp click-to-call
  - ✅ Google Business integration
  - ✅ 72-hour delivery guarantee

**Social Proof Section**

- Testimonial cards (if available, or placeholder for Phase 1)
- Trust badges: "VAT Registered", "UK Based", "Under 1s Load Time Guaranteed"

**Final CTA Section**

- **Headline:** "Your Competitors Are Upgrading. Are You?"
- **CTA Button:** "Build My Demo Site (Free)" → WhatsApp prefill message
- **Subtext:** "No credit card. No calls. We build first, you claim later."

---

### **2. How It Works** (`/how-it-works`)

**Purpose:** Explain the "No-Meeting Funnel" in detail. Remove all friction/doubt.

#### Sections:

**The Build-First Process**

1. **You Request a Demo** — "Send us a WhatsApp or email with your business name and Checkatrade URL. No forms, no sales calls, no discovery meetings."
2. **We Build Your Demo** — "Within 48 hours, we create a high-precision demo using your existing reviews and photos on `yourname.snapbilt.co.uk`"
3. **You Review the Loom** — "2-minute video walkthrough of your new SnapBilt site. Clear, factual, no pressure."
4. **You Decide** — "Love it? Click 'Claim Now' and the 72-hour full build begins. Not ready? Keep the demo link to revisit anytime."
5. **You Go Live** — "We deploy to your domain. You own everything—code, content, images. We disappear (or stay for £30/mo hosting)."

**FAQ Accordion**

- "What if I don't like the draft?" → "Unlikely. But we offer 1 round of changes (focused tweaks, not redesigns)."
- "Do I need to provide content?" → "No. We scrape Checkatrade, Google, your fleet photos, etc."
- "What if I don't have a domain?" → "We'll register one for you (£12/year) or use your existing."
- "Can I cancel hosting later?" → "Yes. You own the code. Export anytime."
- "What about SEO?" → "Built-in: Fast load, mobile-first, schema markup. We can add local SEO for +£500."

---

### **3. Examples** (`/examples`)

**Purpose:** Live proof. Let prospects explore real SnapBilt builds.

#### Sections:

**Filterable Gallery**

- Filter by: Industry (Roofing, Solar, HVAC), Region (London, Surrey, etc.)
- Each card shows:
  - Screenshot preview
  - Contractor name (anonymized or real, depending on permission)
  - Page Speed score (green badge)
  - Review count pulled
  - "View Live Site" link → Opens subdomain

**Case Study Deep-Dive** (1-2 featured)

- **Before/After Metrics:**
  - Load time: 8.2s → 0.7s
  - Mobile usability: 45/100 → 98/100
  - Lead form submissions: +240% (if we have data)
- **Contractor Quote:** "I got 3 enquiries in the first week. Paid for itself immediately." (placeholder for now)

---

### **4. Pricing** (`/pricing`)

**Purpose:** Reinforce the "One Job ROI" anchor. Remove price objections.

#### Sections:

**Single Pricing Tier** (No choice paralysis)

- **SnapBilt Standard:** £2,500 - £4,000
  - 72-hour delivery
  - Mobile-first design
  - Review integration (Checkatrade, Google)
  - Contact forms + WhatsApp
  - Core Web Vitals optimized
  - 1 round of revisions
- **Optional Add-Ons:**
  - Managed Hosting: £30/mo
  - Local SEO Package: +£500
  - Custom Domain Setup: +£50

**ROI Calculator** (Interactive)

- Input: "Average re-roofing job value" (default: £15,000)
- Output: "This site pays for itself after 1 lead. Every lead after = pure profit."

**Comparison Table**
| | Traditional Agency | DIY Builder | SnapBilt |
|---|---|---|---|
| **Time** | 6-8 weeks | Months (you're busy) | 72 hours |
| **Cost** | £5,000 - £15,000 | "Free" (your time isn't) | £2,500 - £4,000 |
| **Meetings** | 5-10 discovery calls | None (you do it all) | Zero |
| **Speed** | Slow (bloated code) | Slow (template limits) | <1s (optimized) |
| **Reviews** | Manual upload | You copy-paste | Auto-imported |

---

### **5. About** (`/about`)

**Purpose:** Build trust. Show we're UK-focused, contractor-obsessed, not a generic agency.

#### Sections:

**Our Story**

- "We're not a web agency. We're contractor advocates."
- "We saw elite roofers with 500+ five-star reviews losing £50k jobs to cowboys with flashy sites."
- "So we productized the solution: SnapBilt. Fixed price. Fixed time. Zero friction."

**Why We're Different**

- ✅ **We Build First** — No "discovery calls." We prove value upfront.
- ✅ **Contractor-Obsessed** — We only work with trades (roofing, solar, HVAC, landscaping).
- ✅ **Speed Fanatics** — Every site loads in <1s. Non-negotiable.
- ✅ **UK-Market Focus** — We understand Checkatrade, Trustpilot, local SEO, VAT.

**Team** (Optional, Phase 2)

- Photo + bio of founder(s)
- "UK-managed operations serving premium contractors"

---

### **6. Contact** (`/contact`)

**Purpose:** WhatsApp-first. Avoid forms when possible.

#### Sections:

**Primary CTA**

- **"Start Your 72-Hour Build"**
- Big WhatsApp button with prefilled message:
  - "Hi! I'm interested in seeing a SnapBilt demo for my roofing business: [Business Name]. Let's talk!"
- **Alternative:** SMS option (UK number)

**Backup Contact Form** (For slower leads)

- Name
- Business Name
- Phone
- Checkatrade URL (optional, helps us build demo faster)
- Message
- CTA: "Send Message" → Triggers email + WhatsApp notification to us

**FAQ Link**

- "Have questions? Check our [How It Works](#) page first."

---

## 🧩 Key Components & Features to Build

### **Global Components**

1. **Navigation Bar**
   - Logo (SnapBilt)
   - Links: How It Works, Examples, Pricing, About
   - CTA Button: "Get My Demo" (sticky, always visible)
   - Mobile: Hamburger menu

2. **Footer**
   - Links: Privacy Policy, Terms, Contact
   - Social proof: "Built for UK Contractors. <1s Load Time Guaranteed."
   - Optional: Trust badges (SSL, UK-based, etc.)

3. **WhatsApp Floating Button**
   - Fixed bottom-right
   - Pulse animation to draw attention
   - Prefilled message on click

### **Interactive Features**

1. **Before/After Slider** (Homepage Hero)
   - Drag slider to compare "Zombie Site" vs. "SnapBilt Site"
   - Shows speed difference (8s vs 0.7s)

2. **3rd Party Speed Test Hook** (Homepage/Examples)
   - "Test Your Site" field that deep-links to PageSpeed Insights or GTMetrix with a SnapBilt comparison overlay.
   - Use Google PageSpeed Insights API for real-time score fetching if possible.

3. **Live Subdomain Previews** (Examples page)
   - Embed iframes or screenshot links
   - Hover shows Page Speed score

4. **ROI Calculator** (Pricing page)
   - Simple input: Job value
   - Output: Break-even after X leads

5. **Loom Video Embed** (How It Works)
   - Example "Loom Video" showing the outreach process
   - Placeholder for now, record real one later

### **Technical Requirements**

- **SEO & Authority:**
  - LocalBusiness Schema Markup (Review JSON-LD)
  - Semantic HTML architecture for roofing/contracting keywords
  - High-precision Meta Descriptions (conversion-focused)
- **Core Web Vitals Optimization:**
  - LCP <0.8s
  - FID <100ms
  - CLS <0.1
- **Mobile-First:** 90%+ of contractor searches happen on mobile
- **Lazy Loading:** Images only load when visible
- **Analytics:** Google Analytics 4 + Facebook Pixel (for retargeting)
- **SEO Basics:**
  - Meta tags (title, description)
  - Open Graph (for social shares)
  - Schema markup (LocalBusiness, Service)

---

## 🚀 Implementation Status

### **✅ COMPLETED - Phase 1 (MVP)**

**Pages:**

- ✅ Homepage (`/`) - All sections implemented
  - ✅ Hero Section (Split-screen Zombie vs SnapBilt comparison)
  - ✅ Problem Section ("Directory Tax" with stat cards)
  - ✅ Solution Section (72-Hour Sprint timeline)
  - ✅ Strategy Section (Build-first process)
  - ✅ Examples Section (Live subdomain demo cards)
  - ✅ Pricing Section (Interactive ROI calculator)
  - ✅ Contact/Footer Section (WhatsApp CTA + trust badges)
- ✅ How It Works (`/how-it-works`) - Full process breakdown
  - ✅ 5-Step "Build-First Process" walkthrough (customer-initiated, permission-based)
  - ✅ FAQ Accordion (4 common questions)
  - ✅ WhatsApp CTA integration
- ✅ Terms of Service (`/terms`) - Legal page
- ✅ Privacy Policy (`/privacy`) - GDPR-compliant privacy page
- ✅ Strategy (`/strategy`) - Detailed build process explanation
- ✅ Example Sites (Live demonstrations)
  - ✅ Apex Roofing (`/examples/roofing`) - Roofing contractor demo
  - ✅ Surrey Solar (`/examples/solar`) - Solar installation demo
  - ✅ Elite HVAC (`/examples/hvac`) - HVAC contractor demo

**Components:**

- ✅ Navbar (Fixed, mobile-responsive, smart routing)
- ✅ Footer (Integrated into Contact component)
- ✅ Scroll-to-Top Button (Industrial orange, auto-show on scroll)
- ✅ Route Change Handler (Auto-scroll on navigation)
- ✅ Pricing Card (£2,500 anchor with feature list)
- ✅ ROI Calculator (Interactive job value input)
- ✅ CTA Sections (Reusable WhatsApp-first buttons)

**Design System:**

- ✅ Industrial Aesthetic (Safety Orange #FF5F1F, Obsidian #0B0B0B)
- ✅ Custom Tailwind Theme Extensions
- ✅ Typography System (Inter + JetBrains Mono)
- ✅ Mobile-First Responsive Design

**Integrations:**

- ✅ WhatsApp Click-to-Chat (Centralized in `config/constants.js`)
- ✅ React Router DOM (Multi-page navigation)
- ✅ SEO Foundation (Meta/OG tags, Sitemap.xml, Robots.txt)
- ✅ App Performance (Route-based code splitting with `React.lazy`)
- ⏳ Google Analytics 4 (Script placeholder added)
- ⏳ Contact Form Email Notifications (Pending)

### **📋 Phase 2 - Next Steps**

#### **Immediate Priorities (Week 2)**

1. **Analytics & Tracking**
   - [x] WhatsApp click event tracking (Centralized pre-filled messages)
   - [ ] Google Analytics 4 integration (Script added to index.html)
   - [ ] Facebook Pixel (for retargeting)
   - [ ] Hotjar/Microsoft Clarity (user behavior tracking)

2. **Performance Optimization**
   - [x] Code splitting (React.lazy implemented for all routes)
   - [ ] Image optimization (convert to WebP, lazy loading)
   - [ ] Lighthouse audit + Core Web Vitals optimization
   - [ ] CDN setup for static assets

3. **SEO Foundation**
   - [x] Meta tags for all pages (title, description, OG tags)
   - [x] Sitemap.xml generation
   - [x] robots.txt configuration
   - [ ] Schema.org markup (LocalBusiness, Service)
   - [ ] Canonical URLs

4. **Real Content Integration**
   - [x] Create 3 example demo pages (Apex Roofing, Surrey Solar, Elite HVAC)
   - [x] Build example routes (/examples/roofing, /examples/solar, /examples/hvac)
   - [ ] Deploy to actual subdomains (e.g., apex.snapbilt.co.uk) instead of routes
   - [ ] Record actual Loom video for "How It Works" page
   - [x] Replace placeholder WhatsApp number with real UK number (Centralized in constants.js)

#### **Phase 3 - Enhancement Features (Week 3-4)**

1. **Examples/Portfolio Page Enhancement**
   - [ ] Filterable gallery (by Industry: Roofing, Solar, HVAC)
   - [ ] Region filter (London, Surrey, Manchester, etc.)
   - [ ] Live iframe previews (with permission)
   - [ ] Before/After case studies with metrics

2. **About Page** (`/about`)
   - [ ] "Our Story" section
   - [ ] "Why We're Different" (4 key differentiators)
   - [ ] Team section (optional, Phase 2)
   - [ ] UK-based transparency messaging

3. **Lead Capture Optimization**
   - [ ] Exit-intent popup (subtle, non-aggressive)
   - [ ] Scroll-depth triggered CTA
   - [ ] Alternative contact form (for non-WhatsApp users)
   - [ ] Email notification system (Resend/Mailgun)

4. **Interactive Features**
   - [ ] Before/After image slider (Zombie Site vs SnapBilt)
   - [ ] Live speed test embed (show real-time PageSpeed)
   - [ ] Testimonial carousel (when available)

5. **Legal & Trust**
   - [ ] Privacy Policy page
   - [ ] Terms of Service page
   - [ ] Cookie consent banner (GDPR compliance)
   - [ ] SSL certificate (Let's Encrypt)

#### **Phase 4 - Advanced Features (Month 2+)**

1. **Automated Demo Generation**
   - [ ] Subdomain request form
   - [ ] Auto-scrape Checkatrade data (if prospect provides URL)
   - [ ] Automated subdomain deployment pipeline
   - [ ] Email notification when demo is ready

2. **Content Marketing**
   - [ ] Blog setup (`/blog`)
   - [ ] First 3 SEO articles:
     - "Why Roofers Are Losing Leads to Better Websites"
     - "The True Cost of Checkatrade (And How to Break Free)"
     - "How to Get a £15k Re-Roofing Lead Without Paying £500 for It"
   - [ ] Case study template

3. **Conversion Rate Optimization (CRO)**
   - [ ] A/B test headlines ("Stop Losing Leads" vs "Get More Jobs")
   - [ ] Test CTA button text ("Claim Demo" vs "Build My Site")
   - [ ] Heatmap analysis (where users click/scroll)
   - [ ] Optimize mobile CTA placement

4. **Backend Integration**
   - [ ] CRM integration (HubSpot/Pipedrive for lead tracking)
   - [ ] Automated WhatsApp responses (Twilio API)
   - [ ] Zapier workflows (WhatsApp → Slack → CRM)

### **🎯 Success Metrics to Track**

**Primary KPIs:**

- WhatsApp click-through rate (CTR)
- Homepage → How It Works page flow
- Time spent on Pricing section
- Scroll depth (% reaching Contact section)

**Secondary Metrics:**

- Bounce rate by page
- Mobile vs Desktop conversion rates
- Traffic sources (Direct, Organic, Referral)
- Return visitor rate

**Launch Readiness Checklist:**

- ✅ Homepage fully functional
- ⚠️ Mobile responsive design (IN PROGRESS - see Bugs section)
- ✅ WhatsApp integration working
- ⏳ Analytics installed
- ⏳ Meta tags added
- ✅ Demo example pages built
- ⏳ Real demo subdomains live (using routes currently)
- ⏳ Performance audit passed (Lighthouse >90)

---

## 🐛 KNOWN BUGS & ISSUES

### **Critical (Mobile-First Priority)**

_No active critical bugs_

---

### **Medium Priority**

_No medium priority bugs tracked yet_

---

### **Low Priority / Enhancement Requests**

_No low priority issues tracked yet_

---

### **Bug Triage Process**

1. **Report Bug:** Add to this section with BUG-XXX identifier
2. **Assign Priority:**
   - P0 (Critical): Breaks mobile experience, blocks launch
   - P1 (High): Affects user experience significantly
   - P2 (Medium): Minor UX issue, doesn't block core functionality
   - P3 (Low): Enhancement or nice-to-have
3. **Fix & Test:** Always test on mobile devices first
4. **Close:** Move to "Fixed Bugs" section below when resolved

---

### **✅ Fixed Bugs**

- [x] **BUG-001:** Hero section visual (video container) slightly cut off on mobile (iPhone 14/Pro Max).
- [x] **BUG-002:** Example sites (Apex, Elite, Surrey) have horizontal overflow or container clipping on mobile.
- [x] **BUG-003:** CTA Buttons "Fix my presence" and "Build my demo free" not linking correctly (need WhatsApp).

### **Deployment Plan**

1. **Staging Environment** (Week 2)
   - [ ] Deploy to Vercel/Netlify staging URL
   - [ ] Test all links and navigation
   - [ ] Mobile device testing (iOS Safari, Chrome Android)
   - [ ] Speed test on 3G network

2. **Production Launch** (Week 3)
   - [ ] Custom domain setup (snapbilt.co.uk or .com)
   - [ ] SSL certificate configuration
   - [ ] CDN setup (Cloudflare)
   - [ ] Analytics verification
   - [ ] Soft launch (share with inner circle for feedback)

3. **Post-Launch** (Week 4)
   - [ ] Monitor analytics daily
   - [ ] Fix any bugs reported
   - [ ] Optimize based on user behavior data
   - [ ] Begin outreach to first "Whale" prospects

---

## 📐 Design System (Implemented)

### **Colors**

- **Primary (Safety Orange):** #FF5F1F — CTAs, highlights, industrial precision
- **Obsidian (Background):** #0B0B0B — Deep black, professional backdrop
- **Accent (Success Green):** #10B981 — Speed indicators, ROI, go-live
- **Alert (Red):** #EF4444 — Problem/urgency, "Directory Tax" warnings
- **Neutral (Grays):** #64748b, #94a3b8 — Body text, subtle elements

### **Typography**

- **Headings:** Inter Bold (uppercase, italic for emphasis)
- **Body:** Inter Regular/Medium
- **Monospace:** JetBrains Mono (for speed metrics like "0.7s", technical elements)

### **Spacing**

- Tailwind's default scale (4, 8, 16, 24, 32, 48, 64px)
- Generous whitespace for industrial "precision" feel

### **Component Styles**

- **Buttons:** Rounded (xl/2xl), bold uppercase text, hover lift effect, active scale-down
- **Cards:** Subtle shadow, rounded-3xl, border glow on hover, scale transitions
- **Icons:** Lucide React (industrial-weight stroke)
- **Animations:** Subtle fade-ins, smooth transitions, no excessive motion

---

## 🎯 Conversion Optimization Strategy (Applied)

1. **✅ Above-the-Fold CTA:** Hero section has immediate "Claim Your Demo" button
2. **✅ WhatsApp-First:** Multiple WhatsApp CTAs, lower friction than forms
3. **✅ Social Proof Early:** Speed metrics (0.6s-0.8s) shown in Examples section
4. **✅ Anchor Pricing:** "One £15k job = 6x ROI" emphasized throughout
5. **✅ Urgency (Subtle):** "72-hour window" messaging, no fake countdown timers
6. **✅ Industrial Aesthetic:** Orange + Black = High-vis safety gear = Trust + Precision

---

## Next Steps

1. **Build Homepage Hero + Navigation** (Day 1)
2. **Add "How It Works" page** (Day 2)
3. **Pricing page + WhatsApp integration** (Day 3)
4. **Deploy to Vercel/Netlify** (Day 3)
5. **Create 2-3 demo subdomains** (Week 2) → Populate "Examples" page
