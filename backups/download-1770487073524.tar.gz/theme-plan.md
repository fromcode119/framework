# Snapbilt Theme Integration Plan

## Goal
Convert the Snapbilt Vite app into a Fromcode theme and wire CMS content (pages, posts, navigation) into the theme rendering pipeline.

## Theme Packaging
1. Create theme manifest at themes/snapbilt-theme/theme.json with:
   - slug, name, version, description, author
   - ui.entry pointing to the built JS bundle (bundle.js)
   - ui.css listing the built CSS file(s)
   - layouts (at least one default layout)
   - variables and optional variableSchema for theme settings
2. Build Snapbilt into themes/snapbilt-theme/ui:
   - Update Vite config to output to themes/snapbilt-theme/ui
   - Ensure asset base paths are relative so the CMS runtime can serve them
   - Produce bundle.js and theme.css (or equivalent) in ui/
3. Add screenshots and iconUrl in theme.json for marketplace/admin display.

## Frontend Runtime Wiring
1. Use the theme ui entry to bootstrap the Snapbilt UI.
2. Replace React Router with CMS-aware routing if needed:
   - Map CMS Pages by slug to routes
   - Provide a fallback route for 404
3. Add data loaders for CMS content:
   - Navigation: GET /api/v1/collections/navigation?slug=main (or desired slug)
   - Pages: GET /api/v1/collections/pages?slug=:slug
   - Posts: GET /api/v1/collections/posts for listing and /:slug for detail
4. Add a lightweight content adapter layer to normalize CMS blocks to Snapbilt components (if using blocks).

## CMS Content Mapping
1. Define which CMS collections drive each Snapbilt section:
   - Home page sections -> CMS Page content blocks
   - Example pages -> CMS Pages or Posts
   - Nav links -> CMS Navigation items
2. Decide on slug conventions for key routes (/, /how-it-works, /terms, /privacy).
3. Add a settings doc or constants for nav slug, footer links, and CTA targets.

## Build + Distribution
1. Add a build script to copy the Snapbilt build output into themes/snapbilt-theme/ui.
2. Ensure theme.json references the final file names.
3. Package themes/snapbilt-theme for deployment or marketplace upload.

## Verification
1. Activate snapbilt-theme via the admin UI and confirm assets load.
2. Confirm CMS navigation renders and links work.
3. Confirm CMS pages/posts render in the correct routes.
4. Validate performance and ensure no broken asset paths.
