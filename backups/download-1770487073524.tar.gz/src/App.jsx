import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, useInRouterContext } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopOnNavigate from './components/ScrollToTopOnNavigate';

// Lazy load non-critical routes for better performance
const HowItWorks = lazy(() => import('./components/HowItWorks'));
const Terms = lazy(() => import('./components/Terms'));
const Privacy = lazy(() => import('./components/Privacy'));
const Strategy = lazy(() => import('./components/Strategy'));
const ApexRoofing = lazy(() => import('./components/examples/ApexRoofing'));
const SurreySolar = lazy(() => import('./components/examples/SurreySolar'));
const EliteHVAC = lazy(() => import('./components/examples/EliteHVAC'));

// Loading fallback component
const PageLoader = () => (
  <div className="min-h-screen bg-obsidian flex items-center justify-center">
    <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
  </div>
);

const AppContent = () => (
  <div className="min-h-screen bg-obsidian font-sans text-white">
    <ScrollToTopOnNavigate />
    <Navbar />
    <main>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/strategy" element={<Strategy />} />

          {/* Example Sites */}
          <Route path="/examples/roofing" element={<ApexRoofing />} />
          <Route path="/examples/solar" element={<SurreySolar />} />
          <Route path="/examples/hvac" element={<EliteHVAC />} />
        </Routes>
      </Suspense>
    </main>
    <ScrollToTop />
  </div>
);

const App = () => {
  const inRouter = useInRouterContext();

  if (inRouter) {
    return <AppContent />;
  }

  return (
    <Router>
      <AppContent />
    </Router>
  );
};
export default App;
