/**
 * SnapBilt Configuration Constants
 * Centralized location for global variables and business info.
 */

export const CONFIG = {
    WHATSAPP_NUMBER: "447000000000", // Placeholder - Update with real UK number
    EMAIL: "hello@snapbilt.co.uk",
    COMPANY_NAME: "SnapBilt",
    SLOGAN: "Digital Assets for Elite Contractors",
    CURRENCY: "£",
    BASE_URL: "https://snapbilt.co.uk",
};

export const CONTACT_LINKS = {
    WHATSAPP: (text) => `https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,
    EMAIL_PATH: (subject, body) => `mailto:${CONFIG.EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
};
