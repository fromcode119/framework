import App from './App.jsx';
import './index.css';

export const init = () => {
    console.log('[snapbilt-theme] Theme UI Initialized');
    document.body.classList.add('theme-snapbilt');
};

// --- Self-Registration ---
if (typeof window !== 'undefined' && window.Fromcode) {
    const Fromcode = window.Fromcode;
    
    init();

    Fromcode.registerTheme('snapbilt', {
        layouts: {
            LandingLayout: App,
            StandardLayout: App
        }
    });
}
