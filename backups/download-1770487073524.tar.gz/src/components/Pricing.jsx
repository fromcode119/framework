import React, { useState, useEffect } from 'react';
import { Check, Info, TrendingUp, Zap, Calculator, ShieldCheck, X } from 'lucide-react';
import { usePlugins } from '@fromcode/react';

const Pricing = () => {
    const { themeVariables } = usePlugins();
    const [jobValue, setJobValue] = useState(15000);
    const [slots, setSlots] = useState(3);

    const price = themeVariables.standardPrice || "2,500";
    const currency = themeVariables.currency || "£";
    const whatsappNumber = themeVariables.whatsappNumber || "447000000000";
    const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(`I'd like to claim my build slot for ${currency}${price}. Let's get started!`)}`;

    useEffect(() => {
        // "Fakish" dynamic slots for marketing urgency
        const timer = setInterval(() => {
            setSlots(prev => prev > 1 ? prev - (Math.random() > 0.9 ? 1 : 0) : 3);
        }, 10000);
        return () => clearInterval(timer);
    }, []);

    const roi = Math.floor(jobValue / 2500);

    const features = [
        "72-Hour Precision Build",
        "Mobile-First Authority Design",
        "Auto-Imported Review Engine",
        "Sub-1s Load Speed Guaranteed",
        "WhatsApp Click-to-Chat Ready",
        "Google Business Data Sync",
        "Handover in 3 Days"
    ];

    return (
        <section id="pricing" className="py-24 bg-obsidian relative overflow-hidden">
            {/* Background Decor */}
            <div className="absolute inset-0 -z-10 pointer-events-none">
                <div className="absolute top-1/2 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                    <h2 className="text-accent font-black uppercase tracking-[0.2em] text-sm mb-4 italic">The ROI Anchor</h2>
                    <h3 className="text-3xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-tight">
                        One Job Pays for <span className="text-accent">Everything</span>
                    </h3>
                </div>

                <div className="grid lg:grid-cols-2 gap-12 items-start">
                    {/* Pricing Card */}
                    <div className="relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-[2.5rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                        <div className="relative bg-obsidian-light rounded-[2rem] border border-white/10 overflow-hidden">
                            <div className="p-8 md:p-12">
                                <div className="flex justify-between items-start mb-8">
                                    <div>
                                        <h4 className="text-white font-black uppercase italic text-2xl tracking-tight mb-2">SnapBilt Standard</h4>
                                        <p className="text-neutral-dark text-sm font-medium">Single Industry Deployment</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-primary font-black text-4xl italic tracking-tighter leading-none">{currency}{price}</p>
                                        <p className="text-neutral-dark text-[10px] font-bold uppercase tracking-widest mt-2">{themeVariables.hostingPrice || "+ £30/MO HOSTING"}</p>
                                    </div>
                                </div>

                                <div className="space-y-4 mb-10">
                                    {features.map((feature, i) => (
                                        <div key={i} className="flex items-center gap-3">
                                            <div className="flex-shrink-0 w-5 h-5 bg-accent/20 rounded-full flex items-center justify-center border border-accent/30">
                                                <Check className="text-accent w-3 h-3" strokeWidth={4} />
                                            </div>
                                            <span className="text-neutral font-bold uppercase text-[10px] sm:text-xs tracking-wide">{feature}</span>
                                        </div>
                                    ))}
                                </div>

                                <div className="space-y-4">
                                    <a
                                        href={whatsappLink}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="group w-full bg-primary hover:bg-white text-obsidian px-8 py-5 rounded-2xl font-black text-xl transition-all shadow-[0_20px_40px_rgba(255,95,31,0.3)] hover:shadow-primary/40 uppercase italic tracking-tight flex items-center justify-center gap-3 active:scale-[0.98]"
                                    >
                                        Claim My Build Slot
                                        <Zap className="fill-current w-5 h-5 group-hover:scale-125 transition-transform" />
                                    </a>

                                    <div className="flex items-center justify-center gap-2 py-2 px-4 bg-alert/10 border border-alert/20 rounded-xl">
                                        <div className="w-2 h-2 bg-alert rounded-full animate-pulse" />
                                        <p className="text-alert font-black text-[10px] uppercase tracking-widest leading-none">
                                            Only {slots} Build Slots Available This Week
                                        </p>
                                    </div>
                                </div>

                                <p className="text-center text-[9px] text-neutral-dark font-mono mt-6 uppercase tracking-[0.2em] italic opacity-40">
                                    * Priority scheduling for established UK domains
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* ROI Calculator Column */}
                    <div className="space-y-8">
                        <div className="bg-obsidian-light border border-white/10 rounded-[2rem] p-8 md:p-12 relative overflow-hidden group/calc shadow-2xl">
                            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover/calc:opacity-10 transition-opacity">
                                <Calculator size={120} weight="fill" />
                            </div>

                            <div className="flex items-center gap-4 mb-10">
                                <div className="bg-accent/20 p-3 rounded-2xl border border-accent/40">
                                    <Calculator className="text-accent w-6 h-6" />
                                </div>
                                <div>
                                    <h5 className="text-white font-black uppercase italic tracking-widest text-xl">ROI Calculator</h5>
                                    <p className="text-neutral-dark text-[10px] font-bold uppercase tracking-widest mt-1">Project your digital growth</p>
                                </div>
                            </div>

                            <div className="mb-12">
                                <div className="flex justify-between items-end mb-6">
                                    <label className="text-neutral-dark font-black uppercase tracking-widest text-[11px] italic">Typical Job Value</label>
                                    <span className="text-2xl sm:text-3xl text-white font-black italic tracking-tighter leading-none">
                                        £<span className="text-primary">{jobValue.toLocaleString()}</span>
                                    </span>
                                </div>
                                <div className="relative h-12 flex items-center">
                                    <div className="absolute inset-0 h-2 my-auto bg-white/5 rounded-full" />
                                    <input
                                        type="range"
                                        min="5000"
                                        max="50000"
                                        step="1000"
                                        value={jobValue}
                                        onChange={(e) => setJobValue(parseInt(e.target.value))}
                                        className="relative w-full h-1.5 bg-transparent appearance-none cursor-pointer accent-primary z-10"
                                    />
                                </div>
                                <div className="flex justify-between mt-4">
                                    <span className="text-[10px] text-neutral-dark font-mono uppercase font-bold tracking-widest">MIN £5K</span>
                                    <span className="text-[10px] text-neutral-dark font-mono uppercase font-bold tracking-widest">MAX £50K</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 sm:gap-6">
                                <div className="bg-obsidian rounded-2xl p-6 border border-white/5 relative overflow-hidden group/stat shadow-inner">
                                    <div className="absolute -right-2 -bottom-2 opacity-5 scale-150 rotate-12 transition-transform group-hover/stat:rotate-0">
                                        <TrendingUp size={48} />
                                    </div>
                                    <p className="text-[10px] text-neutral-dark font-black uppercase tracking-[0.2em] mb-3 italic leading-none">Break Even</p>
                                    <p className="text-3xl text-white font-black italic tracking-tighter leading-none">1 <span className="text-primary group-hover:text-white transition-colors">JOB</span></p>
                                </div>
                                <div className="bg-accent/10 rounded-2xl p-6 border border-accent/20 relative overflow-hidden group/stat shadow-inner">
                                    <div className="absolute -right-2 -bottom-2 opacity-10 scale-150 -rotate-12 transition-transform group-hover/stat:rotate-0">
                                        <Zap size={48} />
                                    </div>
                                    <p className="text-[10px] text-accent font-black uppercase tracking-[0.2em] mb-3 italic leading-none">Yield Multiplier</p>
                                    <p className="text-3xl text-accent font-black italic tracking-tighter leading-none">{roi}X <span className="text-white group-hover:text-accent transition-colors">ROI</span></p>
                                </div>
                            </div>

                            <div className="mt-10 flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10 group/tip">
                                <div className="bg-primary/20 p-2 rounded-lg group-hover/tip:bg-primary/30 transition-colors">
                                    <Info className="text-primary w-5 h-5 flex-shrink-0" />
                                </div>
                                <p className="text-[11px] sm:text-xs text-neutral font-medium leading-relaxed uppercase tracking-wide">
                                    This asset typically self-funds within the <span className="text-white font-bold italic">first 30 days</span> of lead generation.
                                </p>
                            </div>
                        </div>

                        {/* Elite Standard Anchor Note */}
                        <div className="relative group/anchor">
                            <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/50 to-transparent rounded-[2rem] blur opacity-0 group-hover/anchor:opacity-20 transition duration-500" />
                            <div className="relative flex flex-col sm:flex-row items-center gap-6 p-8 bg-obsidian-light rounded-[2.5rem] border border-white/10 overflow-hidden">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16" />

                                <div className="relative w-16 h-16 sm:w-20 sm:h-20 bg-obsidian rounded-2xl flex items-center justify-center border border-white/10 group-hover/anchor:border-primary/50 transition-all duration-500 shadow-2xl">
                                    <ShieldCheck className="text-primary w-8 h-8 sm:w-10 sm:h-10 group-hover/anchor:scale-110 transition-transform" />
                                    <div className="absolute inset-0 border-2 border-primary/20 rounded-2xl animate-[ping_3s_ease-in-out_infinite]" />
                                </div>

                                <div className="text-center sm:text-left relative">
                                    <div className="flex flex-col sm:flex-row items-center gap-2 mb-2">
                                        <p className="text-white font-black uppercase italic tracking-tighter text-xl sm:text-2xl">Elite Standard Build</p>
                                        <span className="bg-primary/20 text-primary text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest border border-primary/30">Verified</span>
                                    </div>
                                    <p className="text-neutral-dark text-xs sm:text-sm font-bold uppercase tracking-[0.2em]">Zero Bloat • Pure Precision • Maximum Authority</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Legitimacy Check: Comparison Table */}
                <div className="mt-24">
                    <div className="text-center mb-12">
                        <h4 className="text-white font-black uppercase italic text-2xl md:text-3xl tracking-tight mb-2">The Legitimacy Check</h4>
                        <p className="text-neutral-dark text-xs sm:text-sm font-bold uppercase tracking-[0.2em]">Why elite contractors choose SnapBilt</p>
                    </div>

                    <div className="overflow-x-auto pb-4">
                        <table className="w-full text-left border-collapse min-w-[600px]">
                            <thead>
                                <tr className="border-b border-white/10">
                                    <th className="py-6 px-4 text-neutral-dark text-[10px] font-black uppercase tracking-[0.2em]">Metric</th>
                                    <th className="py-6 px-4 text-white font-black uppercase italic tracking-wider bg-primary/10 rounded-t-2xl">SnapBilt</th>
                                    <th className="py-6 px-4 text-neutral-dark text-[10px] font-black uppercase tracking-[0.2em]">Traditional Agency</th>
                                    <th className="py-6 px-4 text-neutral-dark text-[10px] font-black uppercase tracking-[0.2em]">DIY / Cheap Builder</th>
                                </tr>
                            </thead>
                            <tbody className="text-xs sm:text-sm">
                                <tr className="border-b border-white/5 group hover:bg-white/[0.02] transition-colors">
                                    <td className="py-6 px-4 text-neutral font-bold uppercase tracking-wide">Delivery Time</td>
                                    <td className="py-6 px-4 text-primary font-black italic bg-primary/10">72 Hours</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">6-8 Weeks</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Months</td>
                                </tr>
                                <tr className="border-b border-white/5 group hover:bg-white/[0.02] transition-colors">
                                    <td className="py-6 px-4 text-neutral font-bold uppercase tracking-wide">Investment</td>
                                    <td className="py-6 px-4 text-primary font-black italic bg-primary/10">£2,500 - £4k</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">£5,000 - £15k</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Your Time (Massive)</td>
                                </tr>
                                <tr className="border-b border-white/5 group hover:bg-white/[0.02] transition-colors">
                                    <td className="py-6 px-4 text-neutral font-bold uppercase tracking-wide">Discovery Calls</td>
                                    <td className="py-6 px-4 text-primary font-black italic bg-primary/10">Zero</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">5-10 Meetings</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Endless Tweaking</td>
                                </tr>
                                <tr className="border-b border-white/5 group hover:bg-white/[0.02] transition-colors">
                                    <td className="py-6 px-4 text-neutral font-bold uppercase tracking-wide">Load Speed</td>
                                    <td className="py-6 px-4 text-primary font-black italic bg-primary/10">&lt;1.0s Guaranteed</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Slow (3-5s+)</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Bloated (5s+)</td>
                                </tr>
                                <tr className="group hover:bg-white/[0.02] transition-colors">
                                    <td className="py-6 px-4 text-neutral font-bold uppercase tracking-wide">Contractor Reviews</td>
                                    <td className="py-6 px-4 text-primary font-black italic bg-primary/10 rounded-b-2xl">Auto-Imported</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Manual Updates</td>
                                    <td className="py-6 px-4 text-neutral-dark font-medium italic">Copy/Paste</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Pricing;
