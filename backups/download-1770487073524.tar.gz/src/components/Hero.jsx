import React, { useState, useRef, useEffect } from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Timer, Zap, Volume2, VolumeX } from 'lucide-react';
import { usePlugins } from '@fromcode/react';

const Hero = () => {
    const { themeVariables, api } = usePlugins();
    const [isMuted, setIsMuted] = useState(true);
    const [isVideoLoaded, setIsVideoLoaded] = useState(false);
    const [urlInput, setUrlInput] = useState("");
    const videoRef = useRef(null);

    const assetUrl = (path) => `${api.getBaseUrl()}/api/v1/themes/snapbilt/assets/${path}`;

    const handleSpeedTest = (e) => {
        e.preventDefault();
        if (!urlInput) return;

        // Ensure URL has protocol
        const formattedUrl = urlInput.startsWith('http') ? urlInput : `https://${urlInput}`;
        window.open(`https://pagespeed.web.dev/report?url=${encodeURIComponent(formattedUrl)}`, '_blank');
    };

    useEffect(() => {
        let isMounted = true;

        if (videoRef.current) {
            // Safari fix: explicitly set muted
            videoRef.current.defaultMuted = true;
            videoRef.current.muted = true;
            videoRef.current.setAttribute('muted', '');
            videoRef.current.setAttribute('playsinline', '');

            const attemptPlay = async () => {
                try {
                    // Only play if the component is still mounted
                    if (isMounted) {
                        await videoRef.current.play();
                    }
                } catch (error) {
                    // Ignore AbortError as it's often a transient state during load/re-render
                    if (error.name !== 'AbortError') {
                        console.error("Video autoplay failed:", error);
                    }
                }
            };

            attemptPlay();
        }

        return () => {
            isMounted = false;
        };
    }, []);

    const toggleMute = () => {
        if (videoRef.current) {
            videoRef.current.muted = !isMuted;
            setIsMuted(!isMuted);
        }
    };

    return (
        <section className="relative min-h-[100dvh] flex items-center pt-24 pb-24 overflow-hidden bg-obsidian">
            {/* Background Decor */}
            <div className="absolute inset-0 -z-10 pointer-events-none overflow-hidden">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[60px] md:blur-[80px]"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-alert/5 rounded-full blur-[60px] md:blur-[80px]"></div>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                    {/* Content */}
                    <div className="text-center lg:text-left pb-12 lg:pb-0">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary text-xs font-black mb-6 uppercase tracking-tighter border border-primary/30">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                            </span>
                            Industrial Precision Builds
                        </div>

                        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-black text-white leading-[0.95] mb-6 uppercase italic tracking-tighter">
                            Stop Losing £50k+ Leads to <span className="text-primary underline decoration-white/20">Better Websites</span>
                        </h1>

                        <p className="text-lg sm:text-xl text-neutral mb-10 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-medium tracking-tight">
                            72-Hour Precision Websites for Elite UK Contractors.
                            <span className="block font-black text-primary mt-2 uppercase tracking-tight text-base sm:text-lg">Zero Meetings. Zero Revisions. Industrial Speed.</span>
                        </p>

                        <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
                            {(() => {
                                const whatsappNumber = themeVariables.whatsappNumber || "447000000000";
                                const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Hi! I'd like to claim my FREE demo site for my contracting business.")}`;
                                return (
                                    <a
                                        href={whatsappLink}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center justify-center gap-3 bg-primary hover:bg-white text-obsidian px-6 sm:px-10 py-5 rounded-2xl font-black text-lg sm:text-xl transition-all shadow-2xl shadow-primary/40 hover:-translate-y-1 uppercase italic tracking-tight w-full sm:w-auto"
                                    >
                                        Claim Your Demo
                                        <ArrowRight size={24} strokeWidth={3} />
                                    </a>
                                );
                            })()}
                        </div>

                        {/* Speed Test Hook */}
                        <div className="mb-10 max-w-md mx-auto lg:mx-0">
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-dark mb-3 italic">Test Your Current Site Speed</p>
                            <form onSubmit={handleSpeedTest} className="relative group">
                                <input
                                    type="text"
                                    placeholder="Enter your website (e.g. roofinguk.co.uk)"
                                    value={urlInput}
                                    onChange={(e) => setUrlInput(e.target.value)}
                                    className="w-full bg-obsidian-light border border-white/10 rounded-xl px-5 py-4 text-white text-sm font-bold focus:outline-none focus:border-primary/50 transition-all placeholder:text-neutral-dark/50"
                                />
                                <button
                                    type="submit"
                                    className="absolute right-2 top-2 bottom-2 bg-white/5 hover:bg-primary hover:text-obsidian text-primary px-4 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
                                >
                                    Analyze
                                </button>
                            </form>
                            <p className="mt-2 text-[9px] text-neutral-dark font-mono uppercase tracking-wider opacity-60">
                                * Opens official Google PageSpeed Insights report
                            </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 pt-8 border-t border-white/10">
                            <div className="flex items-center gap-2 justify-center lg:justify-start text-neutral-dark">
                                <Timer className="text-primary h-5 w-5 shrink-0" />
                                <span className="font-extrabold uppercase text-[10px] tracking-[0.2em] text-left">72h Delivery</span>
                            </div>
                            <div className="flex items-center gap-2 justify-center lg:justify-start text-neutral-dark">
                                <CheckCircle2 className="text-primary h-5 w-5 shrink-0" />
                                <span className="font-extrabold uppercase text-[10px] tracking-[0.2em] text-left">Zero Friction</span>
                            </div>
                            <div className="flex items-center gap-2 justify-center lg:justify-start text-neutral-dark">
                                <ShieldCheck className="text-primary h-5 w-5 shrink-0" />
                                <span className="font-extrabold uppercase text-[10px] tracking-[0.2em] text-left text-nowrap">Military Security</span>
                            </div>
                        </div>
                    </div>

                    {/* Visual: Video Preview */}
                    <div className="relative group lg:mt-0 mt-8 flex flex-col items-center justify-center w-full">
                        {/* Video Title */}
                        <div className="mb-4 text-center">
                            <h3 className="text-2xl md:text-3xl font-black uppercase italic tracking-tight text-white mb-2">
                                <span className="text-alert">Slow Site</span> vs <span className="text-primary">SnapBilt</span>
                            </h3>
                            <p className="text-sm text-neutral-dark font-mono uppercase tracking-wider">
                                Watch the difference in real-time
                            </p>
                        </div>

                        <div className="relative z-10 rounded-[2rem] shadow-[0_0_50px_rgba(255,95,31,0.15)] overflow-hidden border border-white/10 lg:rotate-2 group-hover:rotate-0 transition-all duration-700 w-full max-w-[280px] min-[400px]:max-w-sm mx-auto">
                            {/* Fake Browser Top */}
                            <div className="bg-obsidian border-b border-white/5 px-4 py-4 flex items-center gap-2">
                                <div className="flex gap-1.5">
                                    <div className="w-2.5 h-2.5 rounded-full bg-alert/50"></div>
                                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                                </div>
                                <div className="ml-4 bg-obsidian-light border border-white/10 rounded-full px-4 py-1 text-[10px] text-neutral-dark font-mono flex-1 text-center tracking-tight truncate">
                                    yoursite.co.uk
                                </div>
                            </div>

                            {/* Video Preview */}
                            <div className="aspect-[11/16] relative overflow-hidden bg-obsidian-light max-h-[600px] [transform:translateZ(0)]">
                                {/* Industrial Loader Shadow */}
                                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-obsidian" />

                                <video
                                    ref={videoRef}
                                    autoPlay
                                    loop
                                    muted
                                    playsInline
                                    webkit-playsinline="true"
                                    preload="metadata"
                                    disableRemotePlayback
                                    onLoadedMetadata={() => setIsVideoLoaded(true)}
                                    className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${isVideoLoaded ? 'opacity-100' : 'opacity-20'}`}
                                >
                                    <source src={assetUrl('video-website.webm')} type="video/webm" />
                                </video>

                                {!isVideoLoaded && (
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <div className="w-8 h-8 border-2 border-primary/20 border-t-primary rounded-full animate-spin"></div>
                                    </div>
                                )}
                            </div>

                            {/* Audio Toggle Button */}
                            <button
                                onClick={toggleMute}
                                className="absolute top-4 right-4 bg-obsidian/80 hover:bg-obsidian text-white p-3 rounded-full border border-white/20 hover:border-primary/50 transition-all z-20 backdrop-blur-sm"
                                aria-label={isMuted ? "Unmute video" : "Mute video"}
                            >
                                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                            </button>
                        </div>

                        {/* Bottom Comparison Labels - Moved below video preview for better transcript visibility */}
                        <div className="bg-obsidian border-t border-white/5 py-4 px-4 overflow-hidden relative">
                            {/* Subtle scanline for labels */}
                            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>

                            <div className="flex items-center justify-between text-center gap-2">
                                <div className="flex-1">
                                    <div className="text-alert text-xs font-black uppercase tracking-wider mb-0.5">😤 Frustrated</div>
                                    <div className="text-[10px] text-neutral-dark font-mono">8s+ Load</div>
                                </div>
                                <div className="text-white/20 text-xl font-black italic tracking-tight">VS</div>
                                <div className="flex-1">
                                    <div className="text-primary text-xs font-black uppercase tracking-wider mb-0.5">😊 Happy</div>
                                    <div className="text-[10px] text-neutral-dark font-mono">&lt;1s Load</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Industrial glow elements - hidden on mobile for performance */}
                    <div className="hidden md:block absolute -top-10 -right-10 w-40 h-40 bg-primary/20 rounded-full blur-[100px] -z-10 animate-pulse"></div>
                    <div className="hidden md:block absolute -bottom-10 -left-10 w-60 h-60 bg-alert/10 rounded-full blur-[100px] -z-10"></div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
