import React, { useState, useEffect } from 'react';
import { ChevronUp } from 'lucide-react';

const ScrollToTop = () => {
    const [isVisible, setIsVisible] = useState(false);

    // Show button when page is scrolled down
    const toggleVisibility = () => {
        if (window.pageYOffset > 300) {
            setIsVisible(true);
        } else {
            setIsVisible(false);
        }
    };

    const scrollToTop = (e) => {
        e.currentTarget.blur(); // Remove focus to reset color state
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    };

    useEffect(() => {
        window.addEventListener('scroll', toggleVisibility);
        return () => window.removeEventListener('scroll', toggleVisibility);
    }, []);

    return (
        <div className={`fixed bottom-8 right-8 z-50 transition-all duration-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}>
            <button
                onClick={scrollToTop}
                className="bg-primary hover:bg-white focus:bg-primary text-obsidian p-4 rounded-xl shadow-2xl shadow-primary/40 transition-all hover:-translate-y-1 active:scale-95 group border border-primary/20"
                aria-label="Scroll to top"
            >
                <ChevronUp className="w-6 h-6 stroke-[3px] group-hover:animate-bounce" />
            </button>
        </div>
    );
};

export default ScrollToTop;
