import React, { useEffect } from 'react';
import Hero from './Hero';
import Problem from './Problem';
import Solution from './Solution';
import Examples from './Examples';
import Pricing from './Pricing';
import Contact from './Contact';

const Home = () => {
    useEffect(() => {
        const schema = {
            "@context": "https://schema.org",
            "@type": "ProfessionalService",
            "name": "SnapBilt",
            "image": "https://snapbilt.co.uk/logo.png",
            "@id": "https://snapbilt.co.uk",
            "url": "https://snapbilt.co.uk",
            "telephone": "+447000000000",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "",
                "addressLocality": "Surrey",
                "postalCode": "",
                "addressCountry": "GB"
            },
            "geo": {
                "@type": "GeoCoordinates",
                "latitude": 51.23,
                "longitude": -0.56
            },
            "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "opens": "09:00",
                "closes": "18:00"
            }
        };

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.text = JSON.stringify(schema);
        document.head.appendChild(script);

        return () => {
            document.head.removeChild(script);
        };
    }, []);

    return (
        <>
            <Hero />
            <Problem />
            <Solution />
            <Examples />
            <Pricing />
            <Contact />
        </>
    );
};

export default Home;
