import React from 'react';
import { ShieldCheck, Zap, Globe, MessageSquare, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePlugins } from '@fromcode/react';

const Contact = () => {
    const { themeVariables } = usePlugins();
    const whatsappLink = `https://wa.me/${themeVariables.whatsappNumber || "447000000000"}?text=${encodeURIComponent("Hi SnapBilt! I'd like to claim my FREE demo site. My business is: [Your Business Name]")}`;

    const trustBadges = [
        {
            icon: <ShieldCheck className="w-8 h-8 text-primary" />,
            label: "UK Based Team",
            sub: "Surrey Operations"
        },
        {
            icon: <Zap className="w-8 h-8 text-primary" />,
            label: "Under 1s Load",
            sub: "Guaranteed Performance"
        },
        {
            icon: <Globe className="w-8 h-8 text-primary" />,
            label: "VAT Registered",
            sub: "Professional Standards"
        }
    ];

    return (
        <section id="contact" className="py-24 bg-obsidian border-t border-white/5 relative overflow-hidden">
            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

                {/* Trust Badges */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
                    {trustBadges.map((badge, index) => (
                        <div key={index} className="flex items-center gap-4 bg-white/5 p-6 rounded-xl border border-white/10 hover:border-primary/30 transition-colors">
                            {badge.icon}
                            <div>
                                <div className="text-white font-bold uppercase tracking-wider text-sm">{badge.label}</div>
                                <div className="text-gray-400 text-xs mt-1">{badge.sub}</div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Final CTA Card */}
                <div className="relative group overflow-hidden rounded-[3rem]">
                    {/* Animated Border/Glow */}
                    <div className="absolute -inset-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-30 group-hover:opacity-100 transition-opacity duration-1000 blur-sm" />

                    <div className="relative bg-[#0A0A0A] px-8 py-20 md:p-24 border border-white/10 text-center">
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />

                        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 mb-10">
                            <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                            <span className="text-white font-black uppercase italic tracking-[0.3em] text-[10px]">No Friction • No Meetings • Pure Execution</span>
                        </div>

                        <h2 className="text-[32px] sm:text-4xl md:text-7xl font-black text-white mb-8 tracking-tighter italic leading-none">
                            YOUR COMPETITORS ARE UPGRADING. <br className="hidden md:block" />
                            <span className="text-primary italic"> ARE YOU?</span>
                        </h2>

                        <p className="text-lg md:text-xl text-neutral max-w-2xl mx-auto leading-relaxed mb-16 font-medium uppercase tracking-tight">
                            We build your demo site <span className="text-white font-black italic">before</span> we even talk.
                            No credit card. No Zoom calls. <br className="hidden sm:block" />
                            Claim your digital asset in <span className="text-white font-black underline decoration-primary/50 underline-offset-4 italic">72 hours.</span>
                        </p>

                        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                            <a
                                href={whatsappLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="group relative flex items-center justify-center gap-4 bg-primary text-obsidian font-black px-8 py-5 sm:px-12 sm:py-6 rounded-2xl transition-all hover:scale-[1.03] active:scale-[0.98] text-lg sm:text-xl shadow-[0_20px_40px_rgba(255,95,31,0.3)] hover:shadow-primary/50"
                            >
                                <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
                                <span className="uppercase tracking-tight text-center">Claim My Demo Site (Free)</span>
                                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-2 transition-transform" />
                            </a>
                        </div>

                        {/* Fallback Form */}
                        <div className="mt-16 max-w-xl mx-auto">
                            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-neutral-dark mb-8 italic">Or Request a Callback via Secure Form</p>
                            <form className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <input
                                    type="text"
                                    placeholder="BUSINESS NAME"
                                    className="bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white text-xs font-bold focus:outline-none focus:border-primary/50 transition-all placeholder:opacity-30"
                                />
                                <input
                                    type="text"
                                    placeholder="PHONE / WHATSAPP"
                                    className="bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white text-xs font-bold focus:outline-none focus:border-primary/50 transition-all placeholder:opacity-30"
                                />
                                <input
                                    type="text"
                                    placeholder="CHECKATRADE URL (OPTIONAL)"
                                    className="sm:col-span-2 bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white text-xs font-bold focus:outline-none focus:border-primary/50 transition-all placeholder:opacity-30"
                                />
                                <button className="sm:col-span-2 bg-white/10 hover:bg-white text-neutral-dark hover:text-obsidian py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all italic">
                                    Send Brief to Precision Team
                                </button>
                            </form>
                        </div>

                        <div className="mt-16 flex flex-col items-center gap-4 pt-10 border-t border-white/5">
                            <div className="flex -space-x-1">
                                {[1, 2, 3, 4, 5].map(i => (
                                    <div key={i} className="w-12 h-12 rounded-xl border-2 border-obsidian bg-neutral-dark/20 flex items-center justify-center text-[12px] font-black italic text-neutral hover:border-primary/50 transition-all hover:-translate-y-1 hover:z-10 overflow-hidden relative group/avatar">
                                        <div className="w-full h-full bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center">
                                            {i === 5 ? '+12' : `S${i}`}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="flex gap-1">
                                    {[1, 2, 3, 4, 5].map(i => (
                                        <Zap key={i} className="w-3 h-3 text-primary fill-primary" />
                                    ))}
                                </div>
                                <p className="text-neutral-dark text-xs font-black uppercase tracking-[0.2em] italic">
                                    12 SITES CURRENTLY IN THE 72-HOUR SPRINT PIPELINE
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer Minimal */}
                <div className="mt-24 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 text-gray-500 text-sm font-mono">
                    <div>© 2026 SNAPBILT. ASSETS FOR ELITE CONTRACTORS.</div>
                    <div className="flex gap-8">
                        <Link to="/strategy" className="hover:text-white transition-colors">STRATEGY</Link>
                        <Link to="/terms" className="hover:text-white transition-colors">TERMS</Link>
                        <Link to="/privacy" className="hover:text-white transition-colors">PRIVACY</Link>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                        SYSTEMS ONLINE.
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Contact;
