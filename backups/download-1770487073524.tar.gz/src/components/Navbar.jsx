import React, { useState, useEffect } from 'react';
import { Menu, X, Zap } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { usePlugins } from '@fromcode/react';

const Navbar = () => {
    const { api, themeVariables } = usePlugins();
    const [isOpen, setIsOpen] = useState(false);
    const [navItems, setNavItems] = useState([]);
    const location = useLocation();
    const isHome = location.pathname === '/';

    useEffect(() => {
        async function fetchNav() {
            try {
                // Fetch main navigation
                const data = await api.get('/collections/navigation?slug=main');
                const menu = Array.isArray(data) ? data[0] : (data?.docs?.[0] || data);
                
                if (menu?.items) {
                    setNavItems(menu.items.map(item => ({
                        name: item.label,
                        href: item.url || (item.page?.slug ? `/${item.page.slug}` : (item.post?.slug ? `/posts/${item.post.slug}` : '#')),
                        type: (item.url?.startsWith('#')) ? 'hash' : 'route'
                    })));
                }
            } catch (e) {
                console.warn("Using fallback navigation", e);
            }
        }
        fetchNav();
    }, [api]);

    // Handle scroll locking when mobile menu is open
    useEffect(() => {
// ... existing scroll locking code ...
    }, [isOpen]);

    const isActive = (link) => {
// ... existing isActive code ...
    };

    const getLink = (href) => {
// ... existing getLink code ...
    };

    const navLinks = navItems.length > 0 ? navItems : [
        { name: 'How It Works', href: '/how-it-works', type: 'route' },
        { name: 'Examples', href: '#examples', type: 'hash' },
        { name: 'Pricing', href: '#pricing', type: 'hash' },
        { name: 'Strategy', href: '/strategy', type: 'route' },
    ];

    return (
// ... existing render code ...
        <nav className="fixed w-full bg-obsidian/80 backdrop-blur-md z-50 border-b border-white/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-20 items-center">
                    {/* Logo */}
                    <Link to="/" className="flex items-center gap-2 group transition-transform hover:scale-105">
                        <div className="bg-primary p-1.5 rounded-lg shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all">
                            <Zap className="text-obsidian w-6 h-6 fill-current" />
                        </div>
                        <span className="text-2xl font-bold tracking-tight text-white uppercase italic">
                            Snap<span className="text-primary transition-colors group-hover:text-white">Bilt</span>
                        </span>
                    </Link>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center gap-8">
                        {navLinks.map((link) => (
                            link.type === 'route' ? (
                                <Link
                                    key={link.name}
                                    to={link.href}
                                    className={`font-medium transition-colors uppercase text-xs tracking-widest font-mono ${isActive(link) ? 'text-primary' : 'text-neutral-dark hover:text-primary'}`}
                                >
                                    {link.name}
                                </Link>
                            ) : (
                                <a
                                    key={link.name}
                                    href={getLink(link.href)}
                                    className={`font-medium transition-colors uppercase text-xs tracking-widest font-mono ${isActive(link) ? 'text-primary' : 'text-neutral-dark hover:text-primary'}`}
                                >
                                    {link.name}
                                </a>
                            )
                        ))}
                        <a
                            href={isHome ? "#contact" : "/#contact"}
                            className="bg-primary hover:bg-primary-dark text-obsidian px-6 py-2.5 rounded-full font-black uppercase text-sm transition-all shadow-lg shadow-primary/20 hover:scale-105 active:scale-95"
                        >
                            Get My Demo
                        </a>
                    </div>

                    {/* Mobile Menu Button */}
                    <div className="md:hidden flex items-center">
                        <button
                            onClick={() => setIsOpen(!isOpen)}
                            className="text-white hover:text-primary transition-colors"
                        >
                            {isOpen ? <X size={28} /> : <Menu size={28} />}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Navigation */}
            {isOpen && (
                <div className="md:hidden bg-obsidian border-b border-white/5">
                    <div className="px-4 pt-2 pb-6 space-y-2">
                        {navLinks.map((link) => (
                            link.type === 'route' ? (
                                <Link
                                    key={link.name}
                                    to={link.href}
                                    className={`block px-3 py-4 text-sm font-bold rounded-lg transition-colors uppercase tracking-widest font-mono ${isActive(link) ? 'text-primary bg-white/5' : 'text-neutral hover:text-primary hover:bg-white/5'}`}
                                    onClick={() => setIsOpen(false)}
                                >
                                    {link.name}
                                </Link>
                            ) : (
                                <a
                                    key={link.name}
                                    href={getLink(link.href)}
                                    className={`block px-3 py-4 text-sm font-bold rounded-lg transition-colors uppercase tracking-widest font-mono ${isActive(link) ? 'text-primary bg-white/5' : 'text-neutral hover:text-primary hover:bg-white/5'}`}
                                    onClick={() => setIsOpen(false)}
                                >
                                    {link.name}
                                </a>
                            )
                        ))}
                        <div className="pt-4 px-3">
                            <a
                                href={getLink("#contact")}
                                onClick={() => setIsOpen(false)}
                                className="block w-full bg-primary text-obsidian px-6 py-4 rounded-xl font-black uppercase text-center text-sm shadow-lg shadow-primary/20"
                            >
                                Get My Demo Site
                            </a>
                        </div>
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navbar;
