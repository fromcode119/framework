import React, { useState, memo } from 'react';
import { Link } from 'react-router-dom';
import { CONTACT_LINKS } from '../../config/constants';
import {
    Hammer,
    ShieldCheck,
    Star,
    Timer,
    ArrowRight,
    MessageSquare,
    Phone,
    MapPin,
    CheckCircle2,
    Menu,
    X,
    ChevronRight,
    Award
} from 'lucide-react';

// Memoized Sub-components for hydration speed
const ServiceCard = memo(({ service }) => (
    <div className="p-8 rounded-3xl border border-slate-700 bg-slate-800/50 hover:border-orange-500/50 hover:shadow-2xl hover:shadow-red-900/20 transition-all duration-300">
        <div className="bg-orange-800/10 w-14 h-14 rounded-2xl flex items-center justify-center mb-6 border border-orange-500/30">
            {service.icon}
        </div>
        <h3 className="text-xl font-bold mb-4 text-white">{service.title}</h3>
        <p className="text-slate-300 leading-relaxed text-sm font-medium">{service.desc}</p>
    </div>
));

const ReviewCard = memo(({ review }) => (
    <div className="bg-slate-900/50 md:backdrop-blur-xl p-10 rounded-[2rem] shadow-sm border border-slate-700 flex flex-col justify-between">
        <div className="space-y-6">
            <div className="flex text-yellow-400">
                {[...Array(review.stars)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
            </div>
            <p className="text-slate-300 text-lg italic leading-relaxed font-medium">&quot;{review.text}&quot;</p>
        </div>
        <div className="mt-8 pt-6 border-t border-slate-700 flex justify-between items-center">
            <div>
                <p className="font-bold text-white">{review.name}</p>
                <p className="text-xs text-slate-400 font-medium">{review.location}, Surrey</p>
            </div>
            <div className="flex items-center gap-2 bg-green-600/20 text-green-400 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border border-green-500/30">
                <CheckCircle2 size={12} /> Verified
            </div>
        </div>
    </div>
));

const ApexRoofing = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const services = [
        {
            title: "Emergency Roof Repairs",
            desc: "24/7 rapid response for storm damage, leaks, and structural issues. We aim to be on-site within 4 hours.",
            icon: <Timer className="w-6 h-6 text-orange-800" />
        },
        {
            title: "Full Roof Replacements",
            desc: "Expertly installed slate, tile, and stone roofing systems with a 25-year structural guarantee.",
            icon: <Hammer className="w-6 h-6 text-orange-800" />
        },
        {
            title: "Flat Roofing Specialists",
            desc: "High-performance GRP Fiberglass and EPDM rubber solutions for modern extensions and garages.",
            icon: <ShieldCheck className="w-6 h-6 text-orange-800" />
        }
    ];

    const reviews = [
        {
            name: "David Richardson",
            location: "Woking",
            text: "The team at Apex were fantastic. They arrived quickly after our roof was damaged in the storm and provided a permanent fix the same day. Highly professional.",
            stars: 5
        },
        {
            name: "Emma Watson",
            location: "Guildford",
            text: "Delighted with our new slate roof. The craftsmanship is evident and the team were a pleasure to have around. Cleaned up every evening.",
            stars: 5
        }
    ];

    const whatsappLink = CONTACT_LINKS.WHATSAPP("Hi Apex Roofing! I saw your site on SnapBilt and need a quote for a roofing project.");

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-orange-800 selection:text-white">
            {/* Professional Demo Header */}
            <div className="bg-slate-900 text-white py-2 px-4 text-center text-[10px] uppercase tracking-[0.3em] font-medium border-b border-white/10">
                SnapBilt Performance Demo • Industry: Roofing • 0.4s Load Time
            </div>

            {/* Top Bar */}
            <div className="hidden lg:block bg-slate-800 text-white py-2 transition-all">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center text-xs font-semibold uppercase tracking-wider">
                    <div className="flex gap-6">
                        <span className="flex items-center gap-2"><MapPin size={14} className="text-orange-400" /> Serving Surrey & South East</span>
                        <span className="flex items-center gap-2"><Timer size={14} className="text-orange-400" /> Emergency 24/7 Hotline</span>
                    </div>
                    <div className="flex gap-6">
                        <a href="tel:07000000000" className="hover:text-red-300 transition-colors tracking-widest">Call: 07000 000000</a>
                    </div>
                </div>
            </div>

            {/* Navigation */}
            <nav className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md shadow-sm border-b border-slate-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="bg-orange-800 p-2 rounded-lg shadow-orange-900/40 shadow-lg">
                            <Hammer className="text-white w-6 h-6" />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-xl font-bold tracking-tight text-white leading-none">Apex Roofing</span>
                            <span className="text-[10px] font-bold uppercase tracking-widest text-orange-400 mt-1">Specialists Ltd</span>
                        </div>
                    </div>

                    <div className="hidden md:flex items-center gap-10">
                        <a href="#services" className="text-sm font-bold text-slate-300 hover:text-orange-400 transition-colors uppercase tracking-wide">Our Services</a>
                        <a href="#reviews" className="text-sm font-bold text-slate-300 hover:text-orange-400 transition-colors uppercase tracking-wide">Testimonials</a>
                        <a
                            href={whatsappLink}
                            className="bg-orange-800 text-white px-7 py-3 rounded-full font-bold text-sm uppercase tracking-wide transition-all hover:bg-orange-900 shadow-lg shadow-orange-900/40 active:scale-95"
                        >
                            Get A Free Quote
                        </a>
                    </div>

                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden text-white p-2">
                        {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
                    </button>
                </div>

                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden bg-slate-800 border-b border-slate-700 py-6 px-4 space-y-4 animate-in fade-in slide-in-from-top-4 duration-300">
                        <a href="#services" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-white">Our Services</a>
                        <a href="#reviews" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-white">Testimonials</a>
                        <a href={whatsappLink} className="block w-full bg-orange-800 text-white text-center py-4 rounded-xl font-bold uppercase">Get A Quote</a>
                    </div>
                )}
            </nav>

            {/* Hero Section */}
            <header className="relative bg-slate-800 pt-16 pb-24 lg:pt-24 lg:pb-32 overflow-hidden">
                <div className="absolute top-0 right-0 w-1/3 h-full bg-orange-800/5 clip-path-hero -z-10 hidden lg:block" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid lg:grid-cols-2 gap-16 items-center">
                        <div className="text-center lg:text-left">
                            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-800/20 text-orange-400 text-xs font-bold mb-8 uppercase tracking-wider border border-orange-500/30">
                                <Award size={14} /> Certified Master Roofer
                            </div>

                            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-white leading-[1.1] mb-8 tracking-tight">
                                Quality Roofing <br className="hidden md:block" />
                                <span className="text-orange-400 font-extrabold relative">
                                    Trusted by Surrey
                                    <span className="absolute bottom-1 left-0 w-full h-3 bg-orange-800/30 -z-10" />
                                </span> <br className="hidden md:block" />
                                Homeowners.
                            </h1>

                            <p className="text-base sm:text-lg text-slate-300 mb-10 leading-relaxed max-w-xl mx-auto lg:mx-0 font-medium">
                                Professional roofing services with a focus on integrity, durability, and craftsmanship.
                                Over 25 years of experience protecting South East homes from the elements.
                            </p>

                            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                                <a
                                    href={whatsappLink}
                                    className="flex items-center justify-center gap-3 bg-orange-800 hover:bg-orange-900 text-white px-8 py-5 rounded-xl font-bold text-lg transition-all shadow-xl shadow-orange-900/40 hover:-translate-y-0.5 active:scale-95 w-full sm:w-auto"
                                >
                                    Instant Quote
                                    <ArrowRight size={20} strokeWidth={3} />
                                </a>
                                <a
                                    href="tel:07000000000"
                                    className="flex items-center justify-center gap-3 bg-slate-700 border border-slate-600 text-white hover:bg-slate-600 px-8 py-5 rounded-xl font-bold text-lg transition-all shadow-sm w-full sm:w-auto"
                                >
                                    <Phone size={20} />
                                    07000 000000
                                </a>
                            </div>

                            <div className="mt-12 flex flex-col sm:flex-row justify-center lg:justify-start items-center gap-6 sm:gap-8 border-t border-slate-700 pt-8">
                                <div className="text-center lg:text-left">
                                    <div className="flex gap-1 text-yellow-400 mb-1 justify-center lg:justify-start">
                                        {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                                    </div>
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">4.9/5 Rating on Checkatrade</p>
                                </div>
                                <div className="hidden sm:block h-10 w-px bg-slate-700" />
                                <div className="flex items-center gap-3">
                                    <ShieldCheck className="text-orange-400 w-8 h-8" />
                                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-tight">Fully Insured <br /> & Guaranteed</span>
                                </div>
                            </div>
                        </div>

                        {/* Interactive Authority Component */}
                        <div className="relative lg:ml-auto w-full max-w-lg mx-auto">
                            <div className="absolute -inset-4 bg-orange-800/10 rounded-[3rem] blur-2xl -z-10 scale-95 opacity-50" />
                            <div className="relative bg-slate-800/80 md:backdrop-blur-xl rounded-[2.5rem] p-6 sm:p-8 md:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-slate-700">
                                <div className="flex items-center gap-3 mb-8">
                                    <div className="bg-orange-800 p-2.5 rounded-xl shadow-lg shadow-blue-100 shrink-0">
                                        <ShieldCheck className="text-white w-6 h-6" />
                                    </div>
                                    <div className="min-w-0">
                                        <h3 className="text-base sm:text-lg font-bold text-white leading-none truncate">Apex Integrity Index</h3>
                                        <p className="text-[9px] sm:text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1 truncate">Surrey Structural Standards</p>
                                    </div>
                                </div>

                                <div className="space-y-6 sm:space-y-8">
                                    {/* Comparison Graphic */}
                                    <div className="bg-slate-900/50 rounded-2xl p-4 sm:p-6 border border-slate-700">
                                        <div className="flex justify-between items-center mb-6">
                                            <span className="text-[9px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Material Performance</span>
                                            <span className="text-[9px] sm:text-[10px] font-bold text-orange-400 uppercase tracking-[0.2em] animate-pulse">Live Test</span>
                                        </div>

                                        <div className="space-y-6">
                                            <div>
                                                <div className="flex justify-between mb-2 gap-2">
                                                    <span className="text-[10px] sm:text-xs font-bold text-white truncate">Apex Premium Slate</span>
                                                    <span className="text-[10px] sm:text-xs font-bold text-orange-400 shrink-0">98% Durability</span>
                                                </div>
                                                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                                                    <div className="h-full bg-orange-800 w-[98%] rounded-full shadow-[0_0_8px_rgba(37,99,235,0.4)]" />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="flex justify-between mb-2 gap-2">
                                                    <span className="text-[10px] sm:text-xs font-bold text-slate-300 truncate">Standard Retail Tiles</span>
                                                    <span className="text-[10px] sm:text-xs font-bold text-slate-500 shrink-0">62% Durability</span>
                                                </div>
                                                <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                                                    <div className="h-full bg-slate-400 w-[62%] rounded-full" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Action Metrics */}
                                    <div className="grid grid-cols-2 gap-3 sm:gap-4">
                                        <div className="p-4 sm:p-5 rounded-2xl bg-orange-800/10 border border-orange-500/30 text-center flex flex-col justify-center min-w-0">
                                            <p className="text-[9px] sm:text-[10px] font-bold text-orange-400 uppercase tracking-widest mb-1 sm:mb-2">Value Impact</p>
                                            <p className="text-xl sm:text-2xl font-black text-white">+15%</p>
                                            <p className="text-[8px] sm:text-[9px] font-bold text-red-300 uppercase mt-0.5 sm:mt-1">Property Equity</p>
                                        </div>
                                        <div className="p-4 sm:p-5 rounded-2xl bg-slate-700/50 border border-slate-600 text-center flex flex-col justify-center min-w-0">
                                            <p className="text-[9px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 sm:mb-2">Wait Times</p>
                                            <p className="text-xl sm:text-2xl font-black text-white">48h</p>
                                            <p className="text-[8px] sm:text-[9px] font-bold text-slate-300 uppercase mt-0.5 sm:mt-1">Guaranteed Start</p>
                                        </div>
                                    </div>

                                    {/* Live Status */}
                                    <div className="pt-2">
                                        <div className="flex items-center justify-between p-3 sm:p-4 bg-slate-900 rounded-xl group cursor-pointer hover:bg-black transition-colors">
                                            <div className="flex items-center gap-3 min-w-0">
                                                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shrink-0" />
                                                <span className="text-[9px] sm:text-[10px] font-bold text-white uppercase tracking-widest truncate">Surveyors active In Surrey</span>
                                            </div>
                                            <ChevronRight className="text-white/40 w-4 h-4 group-hover:translate-x-1 transition-transform shrink-0" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* Credibility Strip */}
            <div className="bg-slate-900 text-white py-12">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center md:text-left">
                        <div className="space-y-1">
                            <div className="text-3xl font-bold text-orange-400">25+</div>
                            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Years Experience</div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-3xl font-bold text-orange-400">100%</div>
                            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Fixed-Price Quotes</div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-3xl font-bold text-orange-400">4,500</div>
                            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Roofs Repaired</div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-3xl font-bold text-orange-400">15YR</div>
                            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Minimum Warranty</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Services */}
            <section id="services" className="py-24 bg-slate-900" style={{ contentVisibility: 'auto' }}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                        <div className="max-w-xl">
                            <div className="text-orange-400 font-bold uppercase tracking-[0.2em] text-xs mb-3">Expertise You Can Count On</div>
                            <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight">Comprehensive Roofing <span className="text-orange-400">Solutions.</span></h2>
                        </div>
                        <a href={whatsappLink} className="text-orange-400 font-bold flex items-center gap-2 group underline-offset-4 hover:underline">
                            View all services <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                        </a>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {services.map((s, idx) => (
                            <ServiceCard key={idx} service={s} />
                        ))}
                    </div>
                </div>
            </section>

            {/* Reviews Section */}
            <section id="reviews" className="py-24 bg-slate-800 border-y border-slate-700" style={{ contentVisibility: 'auto' }}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">What Our Clients Say</h2>
                        <div className="flex justify-center items-center gap-2 mb-2">
                            {[...Array(5)].map((_, i) => <Star key={i} size={20} className="text-yellow-400 fill-current" />)}
                        </div>
                        <p className="text-slate-400 font-bold text-xs uppercase tracking-[0.2em]">Verified Checkatrade Reviews</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-8">
                        {reviews.map((r, idx) => (
                            <ReviewCard key={idx} review={r} />
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-24 bg-slate-900">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-orange-800 rounded-[3rem] px-8 py-16 md:p-20 text-center text-white relative overflow-hidden shadow-2xl shadow-orange-900/50">
                        {/* Abstract Background Shapes */}
                        <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl opacity-50" />
                        <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-400/20 rounded-full translate-x-1/3 translate-y-1/3 blur-3xl opacity-50" />

                        <div className="relative z-10">
                            <h2 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-8 tracking-tight">Need a professional <br className="hidden md:block" /> opinion on your roof?</h2>
                            <p className="text-lg md:text-xl text-orange-900/20 mb-12 max-w-2xl mx-auto font-medium">Free, no-obligation site surveys and fixed-price quotes delivered within 24 hours.</p>

                            <div className="flex flex-col sm:flex-row gap-6 justify-center max-w-lg mx-auto">
                                <a href={whatsappLink} className="flex-1 bg-white text-orange-800 px-8 py-5 rounded-xl font-bold text-lg hover:bg-slate-50 transition-all shadow-xl active:scale-95">
                                    Chat on WhatsApp
                                </a>
                                <a href="tel:07000000000" className="flex-1 bg-slate-900 text-white border border-slate-700 px-8 py-5 rounded-xl font-bold text-lg hover:bg-slate-800 transition-all active:scale-95">
                                    Call the Office
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Minimal Footer */}
            <footer className="bg-slate-900 py-16 border-t border-slate-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid md:grid-cols-2 gap-12 items-center text-center md:text-left">
                        <div>
                            <div className="flex items-center justify-center md:justify-start gap-3 mb-6">
                                <div className="bg-orange-800 p-1.5 rounded-md">
                                    <Hammer className="text-white w-4 h-4" />
                                </div>
                                <span className="text-lg font-bold text-white tracking-tight">Apex Roofing Specialists</span>
                            </div>
                            <p className="text-xs text-slate-400 font-medium leading-relaxed uppercase tracking-widest max-w-sm">
                                Serving Woking, Guildford, and surrounding areas <br />
                                Registered UK Contractor • Public Liability Insured (£5m)
                            </p>
                        </div>
                        <div className="flex flex-col md:items-end gap-6">
                            <div className="flex gap-4 justify-center md:justify-end">
                                <div className="w-10 h-10 bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-center text-slate-500 hover:text-orange-400 hover:border-orange-500/50 transition-all cursor-pointer">
                                    <Star size={18} fill="currentColor" />
                                </div>
                                <div className="w-10 h-10 bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-center text-slate-500 hover:text-orange-400 hover:border-orange-500/50 transition-all cursor-pointer">
                                    <MessageSquare size={18} fill="currentColor" />
                                </div>
                            </div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em]">© 2026 Apex Roofing Specialists Ltd. <br className="md:hidden" /> Built by SnapBilt.</p>
                        </div>
                    </div>
                </div>
            </footer>

            {/* Floating Info Banner */}
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md animate-in fade-in slide-in-from-bottom-4 duration-1000">
                <div className="bg-slate-800/90 backdrop-blur-xl border border-slate-700/50 p-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="bg-orange-800 p-2 rounded-lg flex-shrink-0 shadow-lg shadow-red-900/20">
                            <ShieldCheck className="text-white w-4 h-4" />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-[10px] font-black text-white uppercase tracking-tight">Performance Demo</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-0.5">Example Site Only</p>
                        </div>
                    </div>
                    <Link to="/" className="text-[10px] font-black bg-white text-slate-900 px-4 py-2 rounded-xl uppercase tracking-widest hover:bg-slate-200 transition-all active:scale-95">
                        Exit Preview
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ApexRoofing;
