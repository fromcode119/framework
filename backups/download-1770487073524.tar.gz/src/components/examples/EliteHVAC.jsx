import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CONTACT_LINKS } from '../../config/constants';
import {
    Wind,
    Thermometer,
    Wrench,
    Timer,
    Phone,
    MessageSquare,
    ShieldCheck,
    Star,
    CheckCircle2,
    ArrowRight,
    Menu,
    ChevronRight,
    ExternalLink,
    MapPin,
    AlertCircle,
    X,
    Snowflake,
    Flame
} from 'lucide-react';

const EliteHVAC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const services = [
        {
            title: "Expert Boiler Install",
            desc: "Precision installation of A-rated boilers from Worcester Bosch and Vaillant. Optimized for 98% fuel efficiency.",
            icon: <Flame className="w-6 h-6 text-orange-500" />
        },
        {
            title: "Smart Air Conditioning",
            desc: "Whisper-quiet split system cooling with HEPA filtration. Managed via smart-home integration for perfect climate control.",
            icon: <Snowflake className="w-6 h-6 text-blue-400" />
        },
        {
            title: "Emergency 24/7 Breakdown",
            desc: "Priority response teams for heating failures and leaks. We aim for a 60-minute arrival in central London.",
            icon: <AlertCircle className="w-6 h-6 text-red-500" />
        }
    ];

    const whatsappLink = CONTACT_LINKS.WHATSAPP("Hi Elite HVAC! I have an emergency breakdown and need a technician ASAP.");

    return (
        <div className="min-h-screen bg-[#0B1120] text-slate-200 font-sans selection:bg-orange-500 selection:text-white">
            {/* Performance Demo Header */}
            <div className="bg-orange-600 text-white py-2 px-4 text-center text-[10px] uppercase tracking-[0.3em] font-bold">
                SnapBilt Framework Alpha • Industry: HVAC • Server-Side Rendered • 0.4s Finish
            </div>

            {/* Navigation */}
            <nav className="sticky top-0 z-40 bg-[#0B1120]/80 backdrop-blur-xl border-b border-white/5">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="relative">
                            <Wind className="text-orange-500 w-8 h-8 animate-pulse" />
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-[#0B1120]" />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-xl font-bold tracking-tight text-white leading-none">Elite HVAC</span>
                            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-orange-500 mt-1">London Engineering</span>
                        </div>
                    </div>

                    <div className="hidden md:flex items-center gap-10">
                        <a href="#specialisms" className="text-xs font-bold text-slate-400 hover:text-orange-500 transition-colors uppercase tracking-widest font-mono">/Specialisms</a>
                        <a href="#emergency" className="text-xs font-bold text-slate-400 hover:text-orange-500 transition-colors uppercase tracking-widest font-mono">/Emergency</a>
                        <a
                            href={whatsappLink}
                            className="bg-orange-500 text-white px-6 py-2.5 rounded-lg font-bold text-xs uppercase tracking-widest transition-all hover:bg-orange-600 shadow-lg shadow-orange-900/20 active:scale-95 border border-orange-400/20"
                        >
                            Request Tech
                        </a>
                    </div>

                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden text-white">
                        {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>

                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden bg-[#0B1120] border-b border-white/5 py-8 px-6 space-y-6">
                        <a href="#specialisms" onClick={() => setIsMenuOpen(false)} className="block text-sm font-bold uppercase tracking-widest text-slate-400">/Specialisms</a>
                        <a href="#emergency" onClick={() => setIsMenuOpen(false)} className="block text-sm font-bold uppercase tracking-widest text-slate-400">/Emergency</a>
                        <a href={whatsappLink} className="block w-full bg-orange-500 text-white text-center py-4 rounded-xl font-bold uppercase tracking-widest">Book Technician</a>
                    </div>
                )}
            </nav>

            {/* Hero Section */}
            <header className="relative pt-20 pb-32 overflow-hidden border-b border-white/5">
                {/* Technical Grid Background */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                    <div className="grid lg:grid-cols-2 gap-20 items-center">
                        <div>
                            <div className="inline-flex items-center gap-3 px-3 py-1 rounded-md bg-orange-500/10 border border-orange-500/20 text-orange-500 text-[10px] font-bold mb-8 uppercase tracking-[0.3em]">
                                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
                                14 Active Units in SE1
                            </div>

                            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-white leading-[1.05] mb-8 tracking-tighter">
                                Climate Control <br />
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-500">
                                    Redefined.
                                </span>
                            </h1>

                            <p className="text-base sm:text-lg text-slate-400 mb-10 leading-relaxed max-w-xl font-medium tracking-tight">
                                London&apos;s most technologically advanced HVAC firm. We apply engineering precision to
                                home heating and cooling, delivered with sub-1s digital transparency.
                            </p>

                            <div className="flex flex-col sm:flex-row gap-4">
                                <a
                                    href={whatsappLink}
                                    className="flex items-center justify-center gap-3 bg-orange-500 hover:bg-orange-600 text-white px-8 py-5 rounded-xl font-bold text-lg transition-all shadow-xl shadow-orange-900/40 hover:-translate-y-1 active:scale-95"
                                >
                                    Emergency Callout
                                    <Timer size={20} />
                                </a>
                                <a
                                    href="tel:07000000000"
                                    className="flex items-center justify-center gap-3 bg-white/5 border border-white/10 text-white hover:bg-white/10 px-8 py-5 rounded-xl font-bold text-lg transition-all"
                                >
                                    <Phone size={20} />
                                    07000 000000
                                </a>
                            </div>

                            <div className="mt-12 flex items-center gap-8">
                                <div className="flex -space-x-3">
                                    {[...Array(4)].map((_, i) => (
                                        <div key={i} className="w-10 h-10 rounded-full border-2 border-[#0B1120] bg-slate-800" />
                                    ))}
                                </div>
                                <div className="text-xs">
                                    <div className="flex text-orange-500 mb-1">
                                        {[...Array(5)].map((_, i) => <Star key={i} size={12} fill="currentColor" />)}
                                    </div>
                                    <p className="font-bold text-slate-400 uppercase tracking-tighter">2,400+ Trusted Reviews</p>
                                </div>
                            </div>
                        </div>

                        {/* Technical Dashboard Component */}
                        <div className="relative group w-full max-w-lg mx-auto lg:mt-0 mt-12">
                            <div className="absolute -inset-1 bg-gradient-to-r from-orange-500/20 to-blue-500/20 rounded-[2.5rem] blur-2xl opacity-50 group-hover:opacity-100 transition duration-1000" />
                            <div className="relative bg-[#111827] rounded-[2rem] border border-white/10 overflow-hidden">
                                <div className="p-6 sm:p-8 border-b border-white/5 flex justify-between items-center bg-white/5">
                                    <div className="flex gap-1.5 shrink-0">
                                        <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/50" />
                                        <div className="w-2.5 h-2.5 rounded-full bg-orange-500/20 border border-orange-500/50" />
                                        <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500/50" />
                                    </div>
                                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-slate-500 truncate ml-2">Live Diagnostics • Node_084</span>
                                </div>

                                <div className="p-8 sm:p-10 space-y-8 sm:space-y-10">
                                    <div className="space-y-4">
                                        <div className="flex justify-between items-end">
                                            <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Response Integrity</span>
                                            <span className="text-lg sm:text-xl font-bold text-orange-500 font-mono">100%</span>
                                        </div>
                                        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                                            <div className="h-full bg-orange-500 w-[100%] rounded-full shadow-[0_0_10px_rgba(249,115,22,0.5)]" />
                                        </div>
                                    </div>

                                    <div className="space-y-4">
                                        <div className="flex justify-between items-end">
                                            <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Avg. Arrival Time</span>
                                            <span className="text-lg sm:text-xl font-bold text-white font-mono uppercase">42 MIN</span>
                                        </div>
                                        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                                            <div className="h-full bg-blue-500 w-[85%] rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
                                        </div>
                                    </div>

                                    <div className="pt-6 grid grid-cols-2 gap-3 sm:gap-4">
                                        <div className="bg-white/5 p-3 sm:p-4 rounded-xl border border-white/5 text-center min-w-0">
                                            <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Status</p>
                                            <p className="text-[10px] sm:text-xs font-bold text-green-500 uppercase tracking-widest truncate">Operational</p>
                                        </div>
                                        <div className="bg-white/5 p-3 sm:p-4 rounded-xl border border-white/5 text-center min-w-0">
                                            <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Coverage</p>
                                            <p className="text-[10px] sm:text-xs font-bold text-white uppercase tracking-widest truncate">Gr. London</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* Specialisms Section */}
            <section id="specialisms" className="py-24 relative overflow-hidden">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                        <div className="max-w-xl">
                            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">Technical <span className="text-orange-500">Core.</span></h2>
                            <p className="text-slate-400 font-medium">We don&apos;t just fix problems; we optimize systems for longevity and extreme efficiency.</p>
                        </div>
                        <div className="flex gap-4">
                            <div className="bg-white/5 p-3 rounded-xl border border-white/10 hover:border-orange-500/50 transition-colors">
                                <Thermometer className="text-orange-500" />
                            </div>
                            <div className="bg-white/5 p-3 rounded-xl border border-white/10 hover:border-blue-500/50 transition-colors">
                                <Wind className="text-blue-500" />
                            </div>
                        </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {services.map((s, idx) => (
                            <div key={idx} className="p-10 rounded-[2.5rem] bg-[#111827] border border-white/5 hover:border-orange-500/30 transition-all duration-500 group">
                                <div className="mb-8 transform group-hover:scale-110 transition-transform">{s.icon}</div>
                                <h3 className="text-2xl font-bold mb-4 text-white tracking-tight">{s.title}</h3>
                                <p className="text-slate-400 leading-relaxed font-medium text-sm">{s.desc}</p>
                                <div className="mt-8 pt-6 border-t border-white/5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 group-hover:text-orange-500 transition-colors">
                                    Engineering Specs <ChevronRight size={12} />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Emergency CTA */}
            <section id="emergency" className="py-24 bg-gradient-to-b from-white/0 to-orange-500/5">
                <div className="max-w-4xl mx-auto px-4 text-center">
                    <div className="inline-flex py-2 px-6 bg-red-500/10 border border-red-500/20 text-red-500 rounded-full text-xs font-bold uppercase tracking-[.3em] mb-12 animate-pulse">
                        Critical Power & Heating Support
                    </div>
                    <h2 className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tighter leading-none">
                        No Heat? <br />
                        <span className="text-orange-500 italic decoration-orange-500/30 underline font-extrabold underline-offset-8">No Compromise.</span>
                    </h2>
                    <p className="text-xl text-slate-400 mb-12 font-medium max-w-2xl mx-auto leading-relaxed">
                        Priority London response teams active across all boroughs. Book via WhatsApp for
                        real-time GPS technician tracking.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-6 justify-center">
                        <a href={whatsappLink} className="flex-1 bg-orange-500 text-white px-10 py-6 rounded-2xl font-bold text-xl hover:bg-orange-600 transition-all shadow-2xl shadow-orange-900/40 active:scale-95">
                            Request Technician
                        </a>
                        <a href="tel:07000000000" className="flex-1 bg-[#1F2937] text-white border border-white/10 px-10 py-6 rounded-2xl font-bold text-xl hover:bg-[#374151] transition-all active:scale-95">
                            Speak to Office
                        </a>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="py-20 border-t border-white/5 bg-[#0B1120]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-12 text-center md:text-left">
                        <div className="space-y-6">
                            <div className="flex items-center justify-center md:justify-start gap-3">
                                <Wind className="text-orange-500 w-6 h-6" />
                                <span className="text-xl font-bold text-white leading-none uppercase tracking-tighter">Elite HVAC London</span>
                            </div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em] leading-loose">
                                Gas Safe Registered 552910 • F-Gas Certified <br />
                                Commercial & Domestic Climate Engineering
                            </p>
                        </div>

                        <div className="flex flex-col items-center md:items-end gap-6">
                            <a href="/" className="text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:text-white transition-colors flex items-center gap-3 border border-white/5 px-6 py-3 rounded-xl bg-white/5">
                                Powered by SnapBilt Engine
                                <ExternalLink size={12} />
                            </a>
                            <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.2em]">© 2026 Elite HVAC Engineering Ltd.</p>
                        </div>
                    </div>
                </div>
            </footer>

            {/* Floating Info Banner */}
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md animate-in fade-in slide-in-from-bottom-4 duration-1000">
                <div className="bg-slate-900/90 backdrop-blur-xl border border-white/5 p-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="bg-[#FF4D00] p-2 rounded-lg flex-shrink-0 shadow-lg shadow-orange-900/20">
                            <Wind className="text-white w-4 h-4" />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-[10px] font-black text-white uppercase tracking-tight">System Concept</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-0.5">Mock Performance Data</p>
                        </div>
                    </div>
                    <Link to="/" className="text-[10px] font-black bg-white text-slate-900 px-4 py-2 rounded-xl uppercase tracking-widest hover:bg-slate-200 transition-all active:scale-95">
                        Exit Preview
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default EliteHVAC;
