import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CONTACT_LINKS } from '../../config/constants';
import {
    Sun,
    Battery,
    Zap,
    LineChart,
    Star,
    CheckCircle2,
    ArrowRight,
    MessageSquare,
    Phone,
    ShieldCheck,
    Menu,
    ChevronRight,
    Calculator,
    Leaf,
    X,
    TrendingDown,
    ExternalLink
} from 'lucide-react';

const SurreySolar = () => {
    const [bill, setBill] = useState(150);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const savingsPercentage = 0.75; // 75% savings
    const annualSavings = (bill * 12) * savingsPercentage;

    const services = [
        {
            title: "Solar PV Install",
            desc: "Ultra-efficient Tier 1 monocrystalline panels with 440W+ output per module. Engineered for maximum yield in UK overcast conditions.",
            icon: <Sun className="w-6 h-6 text-emerald-600" />
        },
        {
            title: "Smart Battery Storage",
            desc: "Premium LFP battery systems from Tesla and GivenEnergy. Power your home through the night and during grid outages.",
            icon: <Battery className="w-6 h-6 text-emerald-600" />
        },
        {
            title: "Smart EV Integration",
            desc: "Intelligent Zappi and Ohme charging points that prioritize your excess solar energy, allowing you to drive on 100% free sunshine.",
            icon: <Zap className="w-6 h-6 text-emerald-600" />
        }
    ];

    const whatsappLink = CONTACT_LINKS.WHATSAPP("Hi Surrey Solar! I'd like a free site assessment and savings calculation.");

    return (
        <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-emerald-600 selection:text-white">
            {/* SnapBilt Demo Header */}
            <div className="bg-emerald-900 text-white py-2 px-4 text-center text-[10px] uppercase tracking-[0.3em] font-medium border-b border-white/10">
                Performance Demo • Industry: Renewables • 0.5s First Contentful Paint
            </div>

            {/* Navigation */}
            <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-100">
                            <Sun className="text-white w-6 h-6" />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-xl font-bold tracking-tight text-slate-900">Surrey Solar</span>
                            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600 leading-none">Solutions Ltd</span>
                        </div>
                    </div>

                    <div className="hidden md:flex items-center gap-10">
                        <a href="#calculator" className="text-sm font-semibold text-slate-600 hover:text-emerald-600 transition-colors uppercase tracking-wide">Savings Calc</a>
                        <a href="#services" className="text-sm font-semibold text-slate-600 hover:text-emerald-600 transition-colors uppercase tracking-wide">Technology</a>
                        <a
                            href={whatsappLink}
                            className="bg-emerald-600 text-white px-7 py-3 rounded-xl font-bold text-sm uppercase tracking-wide transition-all hover:bg-emerald-700 shadow-lg shadow-emerald-100 active:scale-95"
                        >
                            Free Assessment
                        </a>
                    </div>

                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden text-slate-900">
                        {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>

                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden bg-white border-b border-slate-100 py-6 px-4 space-y-4">
                        <a href="#calculator" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">Savings Calculator</a>
                        <a href="#services" onClick={() => setIsMenuOpen(false)} className="block text-lg font-bold text-slate-900">Our Technology</a>
                        <a href={whatsappLink} className="block w-full bg-emerald-600 text-white text-center py-4 rounded-xl font-bold uppercase">Get Assessment</a>
                    </div>
                )}
            </nav>

            {/* Hero Section */}
            <header className="relative bg-emerald-50/50 pt-16 pb-24 lg:pt-32 lg:pb-40 overflow-hidden">
                <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-600/5 -z-10 blur-3xl rounded-full" />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid lg:grid-cols-2 gap-20 items-center">
                        <div>
                            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-emerald-100 text-emerald-700 text-xs font-bold mb-8 uppercase tracking-wider shadow-sm">
                                <Leaf size={14} className="animate-pulse" /> MCS Certified Installers
                            </div>

                            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-slate-900 leading-[1.1] mb-8 tracking-tight">
                                Zero Your Bills. <br className="hidden md:block" />
                                <span className="text-emerald-600 font-extrabold relative">
                                    Own Your Power.
                                </span>
                            </h1>

                            <p className="text-lg text-slate-600 mb-10 leading-relaxed max-w-xl font-medium">
                                Eliminate energy price hikes forever. Join 1,500+ Surrey homeowners using precision-engineered
                                solar systems built for maximum ROI and 25-year performance.
                            </p>

                            <div className="flex flex-col sm:flex-row gap-4">
                                <a
                                    href={whatsappLink}
                                    className="flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-5 rounded-2xl font-bold text-lg transition-all shadow-xl shadow-emerald-100 hover:-translate-y-1 active:scale-95"
                                >
                                    Book Free Site Survey
                                    <ArrowRight size={20} strokeWidth={3} />
                                </a>
                                <a
                                    href="tel:07000000000"
                                    className="flex items-center justify-center gap-3 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 px-8 py-5 rounded-2xl font-bold text-lg transition-all shadow-sm"
                                >
                                    <Phone size={20} />
                                    07000 000000
                                </a>
                            </div>

                            <div className="mt-12 grid grid-cols-3 gap-8 pt-8 border-t border-emerald-100">
                                <div>
                                    <p className="text-2xl font-bold text-slate-900 tracking-tight">25YR</p>
                                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1">Warranty</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-slate-900 tracking-tight">100%</p>
                                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1">Certified</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold text-slate-900 tracking-tight">£0</p>
                                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1">Upfront</p>
                                </div>
                            </div>
                        </div>

                        {/* Interactive ROI Calculator */}
                        <div id="calculator" className="relative mt-12 lg:mt-0">
                            <div className="absolute -inset-4 bg-emerald-600/10 rounded-[3rem] blur-2xl -z-10 opacity-60" />
                            <div className="bg-white rounded-[2.5rem] p-6 sm:p-8 md:p-12 shadow-[0_20px_50px_rgba(0,0,0,0.08)] border border-emerald-50">
                                <div className="flex items-center gap-3 mb-10">
                                    <div className="bg-emerald-50 p-2 sm:p-3 rounded-2xl">
                                        <Calculator className="text-emerald-600 w-5 h-5 sm:w-6 sm:h-6" />
                                    </div>
                                    <h3 className="text-xl sm:text-2xl font-bold text-slate-900">Savings Estimator</h3>
                                </div>

                                <div className="space-y-10">
                                    <div>
                                        <div className="flex justify-between items-end mb-6">
                                            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-500">Monthly Bill</span>
                                            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">£{bill}</span>
                                        </div>
                                        <input
                                            type="range"
                                            min="50"
                                            max="500"
                                            value={bill}
                                            onChange={(e) => setBill(parseInt(e.target.value))}
                                            className="w-full h-2.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                                        />
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                                        <div className="bg-emerald-50/50 p-5 sm:p-6 rounded-3xl border border-emerald-100">
                                            <div className="flex items-center gap-2 mb-1 sm:mb-2">
                                                <TrendingDown size={14} className="text-emerald-600" />
                                                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Annual Gain</p>
                                            </div>
                                            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-700 italic">£{Math.round(annualSavings)}</p>
                                        </div>
                                        <div className="bg-emerald-900 p-5 sm:p-6 rounded-3xl text-white">
                                            <div className="flex items-center gap-2 mb-1 sm:mb-2">
                                                <CheckCircle2 size={14} className="text-emerald-400" />
                                                <p className="text-[10px] font-bold uppercase tracking-widest text-white/50">Efficiency</p>
                                            </div>
                                            <p className="text-2xl sm:text-3xl font-extrabold text-white italic">A+++</p>
                                        </div>
                                    </div>

                                    <a href={whatsappLink} className="block text-center bg-slate-900 text-white py-4 sm:py-5 rounded-2xl font-bold text-base sm:text-lg hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 active:scale-95">
                                        Get Detailed ROI Report
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* Features Strip */}
            <div className="bg-white py-12 border-y border-slate-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap justify-between gap-8 md:gap-12 grayscale opacity-60">
                    <div className="flex items-center gap-3">
                        <ShieldCheck className="text-emerald-600" />
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-900">HIES Protected</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <LineChart className="text-emerald-600" />
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-900">Smart Monitoring</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Zap className="text-emerald-600" />
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-900">TESLA POWERWALL PRO</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Sun className="text-emerald-600" />
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-900">MCS Accredited</span>
                    </div>
                </div>
            </div>

            {/* Services Grid */}
            <section id="services" className="py-24 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">The Future of <span className="text-emerald-600">Home Energy</span></h2>
                        <p className="text-slate-500 font-medium max-w-2xl mx-auto">We use only premium Tier 1 components to ensure your system performs for decades, not just years.</p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {services.map((s, idx) => (
                            <div key={idx} className="group p-10 rounded-[2.5rem] border border-slate-100 bg-white hover:border-emerald-200 hover:shadow-2xl hover:shadow-emerald-900/5 transition-all duration-300">
                                <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                                    {s.icon}
                                </div>
                                <h3 className="text-2xl font-bold mb-4 text-slate-900 tracking-tight">{s.title}</h3>
                                <p className="text-slate-600 leading-relaxed font-medium text-sm">{s.desc}</p>
                                <div className="mt-8 pt-6 border-t border-slate-50 flex items-center text-emerald-600 font-bold text-xs uppercase tracking-widest">
                                    Learn more <ChevronRight size={14} className="ml-1" />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Testimonial / Social Proof */}
            <section className="py-24 bg-slate-50 border-y border-slate-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <div className="inline-flex items-center gap-1 text-yellow-500 mb-8">
                        {[...Array(5)].map((_, i) => <Star key={i} size={24} fill="currentColor" />)}
                    </div>
                    <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-10 italic">&quot;Our electricity bill dropped from £180 to £14 in the first month. The best investment we&apos;ve made in this house.&quot;</h2>
                    <div className="flex flex-col items-center">
                        <p className="font-bold text-slate-900 text-lg">Dr. Michael Chen</p>
                        <p className="text-sm font-bold text-slate-500 uppercase tracking-widest mt-1">Weybridge Customer</p>
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="py-24">
                <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-emerald-600 rounded-[3rem] p-12 md:p-20 text-center text-white relative overflow-hidden shadow-2xl shadow-emerald-200">
                        {/* Abstract Background Shapes */}
                        <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl opacity-50" />
                        <div className="absolute bottom-0 right-0 w-80 h-80 bg-emerald-400/20 rounded-full translate-x-1/3 translate-y-1/3 blur-3xl opacity-50" />

                        <div className="relative z-10">
                            <h2 className="text-4xl md:text-5xl lg:text-7xl font-bold mb-8 tracking-tight leading-none">Stop Renting Energy. <br className="hidden md:block" /> Start Owning It.</h2>
                            <p className="text-lg md:text-xl text-emerald-50 mb-12 max-w-2xl mx-auto font-medium opacity-90">Free digital site surveys available this week across Surrey. Claim your assessment today.</p>

                            <div className="flex flex-col sm:flex-row gap-6 justify-center max-w-lg mx-auto">
                                <a href={whatsappLink} className="flex-1 bg-slate-900 text-white px-10 py-6 rounded-2xl font-bold text-xl hover:bg-slate-800 transition-all shadow-xl active:scale-95">
                                    Claim Free Assessment
                                </a>
                                <a href="tel:07000000000" className="flex-1 bg-white text-emerald-600 px-10 py-6 rounded-2xl font-bold text-xl hover:bg-emerald-50 transition-all active:scale-95">
                                    Speak to Expert
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="py-20 border-t border-slate-100 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-12">
                        <div className="flex flex-col items-center md:items-start gap-6">
                            <div className="flex items-center gap-3">
                                <div className="bg-emerald-600 p-1.5 rounded-lg shadow-lg shadow-emerald-100">
                                    <Sun className="text-white w-5 h-5" />
                                </div>
                                <span className="text-xl font-bold tracking-tight text-slate-900">Surrey Solar Solutions</span>
                            </div>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-[0.2em] leading-relaxed text-center md:text-left">
                                Platinum GivenEnergy Partner • Tesla Certified Installer <br />
                                Serving the South East for over 15 years.
                            </p>
                        </div>
                        <div className="flex flex-col md:items-end gap-6">
                            <a href="/" className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-emerald-600 transition-colors flex items-center gap-2 border border-slate-100 px-6 py-3 rounded-xl shadow-sm">
                                Built with SnapBilt Framework
                                <ExternalLink size={12} />
                            </a>
                            <p className="text-[10px] text-slate-300 font-bold uppercase tracking-[0.2em]">© 2026 Surrey Solar Solutions Ltd.</p>
                        </div>
                    </div>
                </div>
            </footer>

            {/* Floating Info Banner */}
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md animate-in fade-in slide-in-from-bottom-4 duration-1000">
                <div className="bg-white/80 backdrop-blur-xl border border-emerald-100/50 p-4 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.15)] flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="bg-emerald-600 p-2 rounded-lg flex-shrink-0 shadow-lg shadow-emerald-100">
                            <Sun className="text-white w-4 h-4" />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-[10px] font-black text-slate-900 uppercase tracking-tight">Performance Demo</p>
                            <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-none mt-0.5">Example Site Only</p>
                        </div>
                    </div>
                    <Link to="/" className="text-[10px] font-black bg-slate-900 text-white px-4 py-2 rounded-xl uppercase tracking-widest hover:bg-black transition-all active:scale-95">
                        Exit Preview
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default SurreySolar;
