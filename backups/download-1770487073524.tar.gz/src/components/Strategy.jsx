import React from 'react';
import { ArrowLeft, Target, TrendingUp, Zap, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePlugins } from '@fromcode/react';

const Strategy = () => {
    const { themeVariables } = usePlugins();
    const price = themeVariables.standardPrice || "2,500";
    const currency = themeVariables.currency || "£";

    return (
        <div className="pt-24 pb-12 bg-obsidian text-white min-h-screen">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-white transition-colors mb-8 font-mono text-sm uppercase tracking-wider">
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                </Link>

                <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-6">
                    The SnapBilt <span className="text-primary">Strategy</span>
                </h1>

                <p className="text-xl text-gray-400 mb-12 leading-relaxed">
                    Why we built a productized service for contractors. How we're different from traditional agencies.
                </p>

                <div className="space-y-16">
                    <section>
                        <div className="flex items-center gap-4 mb-6">
                            <div className="bg-primary/20 p-3 rounded-xl border border-primary/30">
                                <Target className="w-8 h-8 text-primary" />
                            </div>
                            <h2 className="text-3xl font-black text-white uppercase italic">The Problem We Saw</h2>
                        </div>
                        <p className="text-neutral-dark leading-relaxed mb-4">
                            Elite UK contractors—roofers, solar installers, HVAC specialists—are masters of their trade.
                            They have 500+ five-star reviews, premium fleets, and decades of experience.
                        </p>
                        <p className="text-neutral-dark leading-relaxed mb-4">
                            But when a £50k lead Googles them? They find a <span className="text-alert font-bold">slow, outdated "Zombie Site"</span> that looks like it was built in 2008.
                        </p>
                        <p className="text-neutral-dark leading-relaxed">
                            Meanwhile, a cowboy with 12 reviews and a slick agency site wins the job. <span className="text-white font-bold">This is the "Legitimacy Gap."</span>
                        </p>
                    </section>

                    <section>
                        <div className="flex items-center gap-4 mb-6">
                            <div className="bg-accent/20 p-3 rounded-xl border border-accent/30">
                                <Zap className="w-8 h-8 text-accent" />
                            </div>
                            <h2 className="text-3xl font-black text-white uppercase italic">Our Solution</h2>
                        </div>
                        <p className="text-neutral-dark leading-relaxed mb-4">
                            We don't do "web design." We provide <span className="text-white font-bold">SnapBilt Assets</span>—fixed-price, 72-hour precision builds.
                        </p>
                        <ul className="space-y-3 text-neutral-dark">
                            <li className="flex items-start gap-3">
                                <span className="text-primary font-black text-xl">→</span>
                                <span><span className="text-white font-bold">No discovery calls.</span> We scrape your Checkatrade/Google data and build the draft first.</span>
                            </li>
                            <li className="flex items-start gap-3">
                                <span className="text-primary font-black text-xl">→</span>
                                <span><span className="text-white font-bold">No endless revisions.</span> One round of focused tweaks. That's it.</span>
                            </li>
                            <li className="flex items-start gap-3">
                                <span className="text-primary font-black text-xl">→</span>
                                <span><span className="text-white font-bold">No bloated code.</span> Sub-1s load times. Mobile-first. Core Web Vitals optimized.</span>
                            </li>
                            <li className="flex items-start gap-3">
                                <span className="text-primary font-black text-xl">→</span>
                                <span><span className="text-white font-bold">Fixed price.</span> {currency}{price}. One job pays for it 6x over.</span>
                            </li>
                        </ul>
                    </section>

                    <section>
                        <div className="flex items-center gap-4 mb-6">
                            <div className="bg-white/10 p-3 rounded-xl border border-white/20">
                                <Users className="w-8 h-8 text-white" />
                            </div>
                            <h2 className="text-3xl font-black text-white uppercase italic">Who We Serve</h2>
                        </div>
                        <p className="text-neutral-dark leading-relaxed mb-6">
                            We focus exclusively on <span className="text-white font-bold">"Whale" contractors</span>:
                        </p>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="bg-white/5 p-6 rounded-2xl border border-white/10">
                                <h3 className="text-xl font-black text-primary uppercase italic mb-3">The Whale</h3>
                                <ul className="space-y-2 text-sm text-neutral-dark">
                                    <li>• 100+ reviews (Checkatrade, Google)</li>
                                    <li>• VAT registered</li>
                                    <li>• £500k+ annual revenue</li>
                                    <li>• High-end projects (£15k - £50k)</li>
                                </ul>
                            </div>
                            <div className="bg-white/5 p-6 rounded-2xl border border-white/10">
                                <h3 className="text-xl font-black text-alert uppercase italic mb-3">The Zombie</h3>
                                <ul className="space-y-2 text-sm text-neutral-dark">
                                    <li>• Strong physical reputation</li>
                                    <li>• Weak digital presence</li>
                                    <li>• Outdated or 1-page site</li>
                                    <li>• Reliant on directories (Checkatrade)</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <section>
                        <div className="flex items-center gap-4 mb-6">
                            <div className="bg-accent/20 p-3 rounded-xl border border-accent/30">
                                <TrendingUp className="w-8 h-8 text-accent" />
                            </div>
                            <h2 className="text-3xl font-black text-white uppercase italic">Why It Works</h2>
                        </div>
                        <p className="text-neutral-dark leading-relaxed mb-6">
                            Traditional agencies charge £5k - £15k and take 6-8 weeks because they treat every project like a custom build.
                            <span className="text-white font-bold"> We productized the solution.</span>
                        </p>
                        <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8 rounded-2xl border border-white/10">
                            <h3 className="text-2xl font-black text-white uppercase italic mb-4">The SnapBilt Formula</h3>
                            <ul className="space-y-3 text-neutral-dark">
                                <li className="flex items-start gap-3">
                                    <span className="text-accent font-black">1.</span>
                                    <span>Use proven templates (optimized for contractor conversions).</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-accent font-black">2.</span>
                                    <span>Auto-import existing data (Checkatrade reviews, photos).</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-accent font-black">3.</span>
                                    <span>Deploy to subdomain first (show, don't tell).</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-accent font-black">4.</span>
                                    <span>WhatsApp-first sales (no "discovery calls").</span>
                                </li>
                            </ul>
                        </div>
                    </section>

                    <section className="bg-white/5 p-8 md:p-12 rounded-3xl border border-white/10">
                        <h2 className="text-3xl font-black text-white uppercase italic mb-6 text-center">The Result?</h2>
                        <p className="text-xl text-neutral-dark text-center leading-relaxed mb-8">
                            Contractors get a <span className="text-white font-bold">conversion-optimized digital asset</span> in 72 hours
                            for <span className="text-primary font-bold">1/3 the cost</span> of traditional agencies.
                        </p>
                        <div className="flex justify-center">
                            <Link
                                to="/"
                                className="bg-primary hover:bg-white text-obsidian px-10 py-5 rounded-full font-black uppercase italic text-lg transition-all hover:scale-105"
                            >
                                See How It Works
                            </Link>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
};

export default Strategy;
