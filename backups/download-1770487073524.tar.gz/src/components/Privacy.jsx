import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { CONFIG } from '../config/constants';

const Privacy = () => {
    return (
        <div className="pt-24 pb-12 bg-obsidian text-white min-h-screen">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-white transition-colors mb-8 font-mono text-sm uppercase tracking-wider">
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                </Link>

                <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-6">
                    Privacy <span className="text-primary">Policy</span>
                </h1>

                <p className="text-gray-400 mb-12 text-sm font-mono">Last Updated: January 23, 2026</p>

                <div className="space-y-12 text-neutral-dark leading-relaxed">
                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">1. Who We Are</h2>
                        <p>
                            SnapBilt is a productized web service for UK contractors. We respect your privacy and are committed to protecting your personal data.
                            This policy explains how we collect, use, and safeguard your information.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">2. Information We Collect</h2>
                        <p className="mb-4">We collect the following data when you use our service:</p>
                        <ul className="space-y-2 list-disc list-inside">
                            <li><span className="text-white font-bold">Contact Information:</span> Name, email, phone number, business name.</li>
                            <li><span className="text-white font-bold">Business Data:</span> Checkatrade URL, Google Business profile, project photos (with your permission).</li>
                            <li><span className="text-white font-bold">Payment Information:</span> Processed securely via Stripe (we do not store card details).</li>
                            <li><span className="text-white font-bold">Analytics:</span> We use Google Analytics to track website usage (anonymized IP addresses).</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">3. How We Use Your Data</h2>
                        <ul className="space-y-2 list-disc list-inside">
                            <li>To build your website (importing reviews, photos, contact forms).</li>
                            <li>To send project updates (via email or WhatsApp).</li>
                            <li>To process payments and issue invoices.</li>
                            <li>To improve our service (analytics, user feedback).</li>
                        </ul>
                        <p className="mt-4 text-white font-bold">
                            We will NEVER sell your data to third parties.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">4. Data Storage & Security</h2>
                        <p className="mb-4">
                            Your data is stored securely on EU-based servers (compliant with GDPR). We use:
                        </p>
                        <ul className="space-y-2 list-disc list-inside">
                            <li>Encrypted connections (SSL/TLS).</li>
                            <li>Secure payment processing (Stripe PCI DSS Level 1).</li>
                            <li>Regular backups (hosted on Vercel/Netlify with enterprise-grade security).</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">5. Third-Party Services</h2>
                        <p className="mb-4">We integrate with the following services (each has their own privacy policy):</p>
                        <ul className="space-y-2 list-disc list-inside">
                            <li><span className="text-white font-bold">Google Analytics:</span> Tracks website usage (you can opt-out via browser extensions).</li>
                            <li><span className="text-white font-bold">Stripe:</span> Processes payments securely.</li>
                            <li><span className="text-white font-bold">WhatsApp:</span> For client communication (end-to-end encrypted).</li>
                            <li><span className="text-white font-bold">Checkatrade/Google:</span> We scrape publicly available reviews (with your consent).</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">6. Your Rights (GDPR)</h2>
                        <p className="mb-4">Under UK GDPR, you have the right to:</p>
                        <ul className="space-y-2 list-disc list-inside">
                            <li><span className="text-white font-bold">Access:</span> Request a copy of your data.</li>
                            <li><span className="text-white font-bold">Correction:</span> Update incorrect information.</li>
                            <li><span className="text-white font-bold">Deletion:</span> Request we delete your data (unless legally required to keep it).</li>
                            <li><span className="text-white font-bold">Portability:</span> Export your data in a machine-readable format.</li>
                        </ul>
                        <p className="mt-4">
                            To exercise these rights, email <a href={`mailto:${CONFIG.EMAIL}`} className="text-primary hover:text-white transition-colors underline">{CONFIG.EMAIL}</a>.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">7. Cookies</h2>
                        <p>
                            We use minimal cookies for analytics and user experience. You can disable cookies in your browser,
                            but some features may not work properly.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">8. Changes to This Policy</h2>
                        <p>
                            We may update this policy periodically. Changes will be posted here with a new "Last Updated" date.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">9. Contact</h2>
                        <p>
                            For privacy-related questions, contact us at <a href="mailto:hello@snapbilt.co.uk" className="text-primary hover:text-white transition-colors underline">hello@snapbilt.co.uk</a>.
                        </p>
                    </section>
                </div>
            </div>
        </div>
    );
};

export default Privacy;
