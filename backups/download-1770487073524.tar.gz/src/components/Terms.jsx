import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { CONTACT_LINKS, CONFIG } from '../config/constants';

const Terms = () => {
    return (
        <div className="pt-24 pb-12 bg-obsidian text-white min-h-screen">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-white transition-colors mb-8 font-mono text-sm uppercase tracking-wider">
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                </Link>

                <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-6">
                    Terms of <span className="text-primary">Service</span>
                </h1>

                <p className="text-gray-400 mb-12 text-sm font-mono">Last Updated: January 23, 2026</p>

                <div className="space-y-12 text-neutral-dark leading-relaxed">
                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">1. The Agreement</h2>
                        <p className="mb-4">
                            By purchasing a SnapBilt website build, you ("Client") agree to the following terms with SnapBilt ("We", "Us", "Our").
                        </p>
                        <p>
                            This is a <span className="text-white font-bold">fixed-scope, productized service</span>. We are not a traditional agency.
                            We build high-performance websites for UK contractors using a proven template system.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">2. The Service</h2>
                        <ul className="space-y-2 list-disc list-inside">
                            <li><span className="text-white font-bold">72-Hour Delivery Window:</span> We commit to delivering your website within 72 business hours from payment confirmation.</li>
                            <li><span className="text-white font-bold">What's Included:</span> Mobile-first design, auto-imported reviews (Checkatrade/Google), contact forms, WhatsApp integration, Core Web Vitals optimization.</li>
                            <li><span className="text-white font-bold">What's NOT Included:</span> Custom animations, e-commerce, booking systems, or features outside the standard SnapBilt template.</li>
                            <li><span className="text-white font-bold">1 Round of Revisions:</span> We offer one round of focused revisions (text changes, image swaps, color tweaks). We do not offer full redesigns.</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">3. Payment Terms</h2>
                        <ul className="space-y-2 list-disc list-inside">
                            <li><span className="text-white font-bold">Price:</span> £2,500 - £4,000 (one-time build fee, depending on complexity).</li>
                            <li><span className="text-white font-bold">Hosting (Optional):</span> £30/month for managed hosting. Cancel anytime.</li>
                            <li><span className="text-white font-bold">Payment Method:</span> Bank transfer or Stripe (invoice sent via email).</li>
                            <li><span className="text-white font-bold">No Refunds:</span> Due to the nature of our productized service, all sales are final once work begins.</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">4. Ownership</h2>
                        <p className="mb-4">
                            <span className="text-white font-bold">You own the website.</span> Once paid, the code, content, and design are yours.
                            If you choose to cancel hosting, you can export the site and host it elsewhere.
                        </p>
                        <p>
                            We retain the right to showcase your site in our portfolio (anonymized if requested).
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">5. Client Responsibilities</h2>
                        <ul className="space-y-2 list-disc list-inside">
                            <li>Provide accurate business information (Checkatrade URL, photos, contact details).</li>
                            <li>Respond to revision requests within 48 hours to keep the project on track.</li>
                            <li>If hosting with us, maintain payment (£30/mo). Failure to pay results in site suspension.</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">6. Limitation of Liability</h2>
                        <p>
                            We guarantee fast, mobile-optimized websites. However, we are not responsible for:
                        </p>
                        <ul className="space-y-2 list-disc list-inside mt-4">
                            <li>Google ranking (SEO takes time and is not guaranteed).</li>
                            <li>Lead volume (your business reputation and market conditions affect this).</li>
                            <li>Third-party integrations breaking (e.g., Checkatrade API changes).</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">7. Cancellation Policy</h2>
                        <p className="mb-4">
                            <span className="text-white font-bold">Before Build Starts:</span> Full refund if you cancel before we begin work.
                        </p>
                        <p className="mb-4">
                            <span className="text-white font-bold">After Build Starts:</span> No refund (you will receive the completed site as-is).
                        </p>
                        <p>
                            <span className="text-white font-bold">Hosting Cancellation:</span> Cancel anytime. No questions asked.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-2xl font-black text-white uppercase italic mb-4">8. Contact</h2>
                        <p>
                            For questions, email us at <a href={`mailto:${CONFIG.EMAIL}`} className="text-primary hover:text-white transition-colors underline">{CONFIG.EMAIL}</a> or WhatsApp <a href={CONTACT_LINKS.WHATSAPP("Terms Inquiry")} className="text-primary hover:text-white transition-colors underline">+{CONFIG.WHATSAPP_NUMBER}</a>.
                        </p>
                    </section>
                </div>
            </div>
        </div>
    );
};

export default Terms;
