import React, { useState } from 'react';
import { Hammer, Video, MousePointer2, Rocket, Plus, Minus, MessageSquare, ArrowRight } from 'lucide-react';
import Contact from './Contact';
import { CONTACT_LINKS } from '../config/constants';

const HowItWorks = () => {
    const steps = [
        {
            icon: <MessageSquare className="w-10 h-10 text-primary" />,
            title: "You Request a Demo",
            desc: "Send us a WhatsApp or email with your business name and Checkatrade URL. That's it. No forms, no sales calls, no discovery meetings."
        },
        {
            icon: <Hammer className="w-10 h-10 text-primary" />,
            title: "We Build Your Demo",
            desc: "Within 48 hours, we create a high-precision demo using your existing reviews and photos. You get a real, live preview site—not a mockup."
        },
        {
            icon: <Video className="w-10 h-10 text-primary" />,
            title: "Review the Performance Report",
            desc: "We send you a 2-minute technical walkthrough benchmarking your current deployment vs. a SnapBilt asset. Purely factual, objective data, no sales pitch."
        },
        {
            icon: <MousePointer2 className="w-10 h-10 text-primary" />,
            title: "You Decide",
            desc: "Love it? Click 'Claim Now' and the 72-hour full build begins. Not ready? No hard feelings—you keep the demo link to revisit anytime."
        },
        {
            icon: <Rocket className="w-10 h-10 text-primary" />,
            title: "You Go Live",
            desc: "We deploy to your domain. You own everything—code, content, images. A sub-1s load speed asset that works on autopilot."
        }
    ];

    const faqs = [
        {
            q: "Why do you build the site before I pay?",
            a: "Because contractors are busy. We want to prove our value immediately with a real demo you can click through—not a pitch deck."
        },
        {
            q: "Do I actually own the website?",
            a: "100%. You own the entire codebase—built on our proprietary React framework (not WordPress). It's military-grade secure, sub-1s load speed, and uses cutting-edge technologies like Vite, Tailwind CSS, and React Router. If you ever want to leave our £30/mo hosting, you take everything with you. No lock-in, no legacy CMS vulnerabilities."
        },
        {
            q: "What if I already have a website?",
            a: "Most of our clients do. We build 'SnapBilt Assets' to replace slow or outdated sites that aren't converting leads into jobs."
        },
        {
            q: "Why not just use Wix or Squarespace?",
            a: "DIY builders are great for hobbyists—not £50k+ contractors. You're paying monthly fees for slow, cookie-cutter templates that scream 'amateur'. Our builds are custom, lightning-fast, and optimized specifically for high-ticket lead conversion. You get a professional asset that matches your expertise, not a drag-and-drop site that looks like everyone else's."
        },
        {
            q: "Why not just use WordPress?",
            a: "Traditional CMS platforms require constant updates, plugin management, and are vulnerable to security exploits. Our proprietary React framework delivers sub-1s load speeds with zero maintenance overhead—just a clean, streamlined asset built on Vite, Tailwind CSS, and modern JavaScript. No bloat, no security patches, no headaches."
        },
        {
            q: "Why no monthly subscriptions for the website?",
            a: "Because your website shouldn't be held hostage. You pay once for the build (£2,500), then only £30/month for hosting. Most agencies charge £100-300/month forever—locking you into recurring fees for a site you don't own. We keep the build and hosting separate so you're always in control."
        },
        {
            q: "Is there a long-term contract?",
            a: "No. The build is a one-time fee. Hosting is £30/month and can be cancelled anytime. We keep clients through results, not contracts."
        },
        {
            q: "What if I hire a freelancer or agency instead?",
            a: "Expect 6-12 weeks of back-and-forth, mood boards, wireframes, and 'rounds of revisions.' You'll pay £5k-15k for something slower than what we deliver in 72 hours. Agencies sell meetings. We sell speed and results."
        }
    ];

    const [openFaq, setOpenFaq] = useState(null);

    return (
        <div className="pt-24 bg-obsidian text-white">
            {/* Header */}
            <header className="py-20 border-b border-white/5 bg-gradient-to-b from-white/5 to-transparent">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h1 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter mb-6">
                        The <span className="text-primary underline">Build-First</span> Process
                    </h1>
                    <p className="text-xl text-neutral-dark max-w-2xl mx-auto font-medium mb-12">
                        No discovery calls. No branding workshops. No endless revisions.
                        Just a high-performance asset delivered in 72 hours.
                    </p>

                    {/* Loom Video Placeholder */}
                    <div className="max-w-4xl mx-auto border border-white/10 rounded-3xl overflow-hidden bg-white/5 shadow-2xl relative group cursor-pointer hover:border-primary/50 transition-all">
                        <div className="aspect-video flex items-center justify-center bg-black/40 relative">
                            <div className="text-center z-10 p-8">
                                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-primary/50 group-hover:scale-110 transition-transform">
                                    <Video className="w-10 h-10 text-primary" />
                                </div>
                                <h3 className="text-2xl font-black uppercase italic mb-2">A Message from the Founder: The SnapBilt Mission</h3>
                                <p className="text-neutral-dark border-b border-primary/30 inline-block">Why we build assets first and disrupt the agency model.</p>
                            </div>
                            {/* Overlay pattern */}
                            <div className="absolute inset-0 opacity-20 pointer-events-none"
                                style={{ backgroundImage: 'radial-gradient(circle, #FF5F1F 1px, transparent 1px)', backgroundSize: '24px 24px' }}>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* Step by Step */}
            <section className="py-24 relative overflow-hidden">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid gap-12 lg:gap-24">
                        {steps.map((step, index) => (
                            <div key={index} className="flex flex-col md:flex-row gap-8 md:gap-16 items-start relative group">
                                {/* Number Decor */}
                                <div className="hidden md:block absolute -left-20 top-0 text-8xl font-black text-white/5 select-none transition-colors group-hover:text-primary/10">
                                    0{index + 1}
                                </div>
                                <div className="bg-white/5 p-6 rounded-3xl border border-white/10 group-hover:border-primary/30 transition-all flex-shrink-0 shadow-2xl">
                                    {step.icon}
                                </div>
                                <div className="pt-2">
                                    <h2 className="text-2xl md:text-3xl font-black uppercase italic mb-4 tracking-tight leading-none group-hover:text-primary transition-colors">
                                        {step.title}
                                    </h2>
                                    <p className="text-lg text-neutral-dark max-w-xl leading-relaxed">
                                        {step.desc}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="py-24 bg-obsidian-light border-y border-white/5">
                <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h3 className="text-3xl md:text-4xl font-black uppercase italic text-center mb-16 tracking-tighter">
                        Common <span className="text-primary">Questions</span>
                    </h3>

                    <div className="space-y-4">
                        {faqs.map((faq, index) => (
                            <div key={index} className="border border-white/10 rounded-2xl overflow-hidden bg-obsidian">
                                <button
                                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                                    className="w-full flex items-center justify-between p-6 text-left hover:bg-white/5 transition-colors"
                                >
                                    <span className="font-bold uppercase tracking-tight text-sm md:text-base pr-4 italic">
                                        {faq.q}
                                    </span>
                                    {openFaq === index ? <Minus className="text-primary w-5 h-5 flex-shrink-0" /> : <Plus className="text-primary w-5 h-5 flex-shrink-0" />}
                                </button>
                                {openFaq === index && (
                                    <div className="px-6 pb-6 text-neutral-dark font-medium leading-relaxed border-t border-white/5 pt-4 text-sm md:text-base">
                                        {faq.a}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Ready Card */}
            <section className="py-24">
                <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-primary p-12 md:p-16 rounded-[3rem] text-obsidian text-center relative overflow-hidden group">
                        <div className="relative z-10">
                            <h4 className="text-3xl md:text-5xl font-black uppercase italic mb-8 tracking-tighter leading-none">
                                Stop Being a <span className="underline decoration-black/20">Zombie.</span> <br />
                                Claim Your Digital Asset.
                            </h4>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                                <a
                                    href={CONTACT_LINKS.WHATSAPP("I'd like to learn more about the process")}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-3 bg-obsidian text-white px-10 py-5 rounded-full font-black uppercase italic text-lg transition-all hover:scale-105 active:scale-95 shadow-2xl"
                                >
                                    <MessageSquare className="w-6 h-6 fill-current" />
                                    START MY BUILD (FREE)
                                    <ArrowRight className="w-5 h-5" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <Contact />
        </div>
    );
};

export default HowItWorks;
