import React from 'react';
import { Users, TrendingDown, Clock, MousePointerClick } from 'lucide-react';
import { CONTACT_LINKS } from '../config/constants';

const Problem = () => {
    const problems = [
        {
            icon: <Users className="w-8 h-8 text-alert" />,
            title: "The Directory Trap",
            description: "Sites like Checkatrade send YOUR lead to 3-5 competitors instantly. It's a race to the bottom on price that you can't win.",
            stat: "5+ Competitors per Lead"
        },
        {
            icon: <TrendingDown className="w-8 h-8 text-alert" />,
            title: "The Legitimacy Gap",
            description: "High-end clients doing 'Deep Research' see a basic or 'Zombie' website and choose the contractor who looks more established.",
            stat: "£15k+ Jobs Lost"
        },
        {
            icon: <Clock className="w-8 h-8 text-alert" />,
            title: "Agency Friction",
            description: "Traditional agencies take 8 weeks and £5,000+ for a custom build. You're too busy for discovery calls and endless revisions.",
            stat: "4-8 Week Delay"
        }
    ];

    return (
        <section id="problem" className="py-24 bg-obsidian-light border-y border-white/5">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                    <h2 className="text-primary font-black uppercase tracking-[0.2em] text-sm mb-4 italic">The Directory Tax</h2>
                    <h3 className="text-3xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-tight">
                        Stop Paying for <span className="text-alert">Diluted Leads</span>
                    </h3>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                    {problems.map((prob, index) => (
                        <div key={index} className="bg-obsidian p-8 rounded-3xl border border-white/5 hover:border-alert/30 transition-all group relative overflow-hidden">
                            <div className="mb-6 bg-alert/10 w-16 h-16 rounded-2xl flex items-center justify-center border border-alert/20 group-hover:scale-110 transition-transform">
                                {prob.icon}
                            </div>
                            <h4 className="text-xl font-black text-white uppercase italic mb-4 tracking-tight">{prob.title}</h4>
                            <p className="text-neutral-dark leading-relaxed mb-6 font-medium">
                                {prob.description}
                            </p>
                            <div className="inline-block bg-alert/20 text-alert px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest border border-alert/30">
                                {prob.stat}
                            </div>

                            {/* Decorative scanline effect on hover */}
                            <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-alert/5 to-transparent -translate-y-full group-hover:translate-y-full transition-transform duration-1000 opacity-20"></div>
                        </div>
                    ))}
                </div>

                <div className="mt-16 bg-alert/5 border border-alert/20 p-8 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="flex items-center gap-6">
                        <div className="w-16 h-16 bg-alert rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-alert/20">
                            <TrendingDown className="text-white w-8 h-8" strokeWidth={3} />
                        </div>
                        <div>
                            <p className="text-white font-black uppercase italic text-xl tracking-tight">The Total Loss</p>
                            <p className="text-neutral-dark font-medium">Poor digital presence costs elite contractors an average of <span className="text-alert font-bold">£50,000+ per year</span> in lost high-ticket conversions.</p>
                        </div>
                    </div>
                    <a
                        href={CONTACT_LINKS.WHATSAPP("I'm losing leads and need to fix my online presence. Can you help?")}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="whitespace-nowrap bg-white text-obsidian px-8 py-4 rounded-xl font-black uppercase italic tracking-tight hover:bg-alert hover:text-white transition-all shadow-xl shadow-white/5 active:scale-95 inline-block text-center"
                    >
                        Fix My Presence
                    </a>
                </div>
            </div>
        </section>
    );
};

export default Problem;
