import React, { useState, useEffect } from 'react';
import { ExternalLink, Star, Gauge, MousePointer2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePlugins } from '@fromcode/react';

const Examples = () => {
    const { api, themeVariables } = usePlugins();
    const [demoItems, setDemoItems] = useState([]);

    useEffect(() => {
        async function fetchDemos() {
            try {
                // Fetch portfolio posts
                const data = await api.get('/collections/posts?category=Examples');
                const posts = data?.docs || (Array.isArray(data) ? data : []);
                
                if (posts.length > 0) {
                    setDemoItems(posts.map(post => ({
                        name: post.title,
                        path: `/posts/${post.slug}`,
                        speed: post.speed || "0.6s",
                        reviews: post.reviews || "100",
                        vitals: post.vitals || { lcp: "0.4s", cls: "0.01", score: "99" },
                        industry: post.industry || (post.categories?.length > 0 ? post.categories[0].name : "General"),
                        color: post.color || "from-blue-600/30 to-slate-900/60",
                        tag: post.tag || "Industrial Build"
                    })));
                }
            } catch (e) {
                console.warn("Using fallback examples", e);
            }
        }
        fetchDemos();
    }, [api]);

    const demos = demoItems.length > 0 ? demoItems : [
        {
            name: "Apex Roofing Specialists",
            path: "/examples/roofing",
            speed: "0.6s",
            reviews: "142",
            vitals: { lcp: "0.4s", cls: "0.01", score: "99" },
            industry: "Roofing",
            color: "from-blue-600/30 to-slate-900/60",
            tag: "Corporate Authority"
        },
        {
            name: "Surrey Solar Solutions",
            path: "/examples/solar",
            speed: "0.5s",
            reviews: "89",
            vitals: { lcp: "0.3s", cls: "0.00", score: "100" },
            industry: "Renewables",
            color: "from-emerald-600/30 to-emerald-900/60",
            tag: "Modern Eco"
        },
        {
            name: "Elite HVAC London",
            path: "/examples/hvac",
            speed: "0.7s",
            reviews: "215",
            vitals: { lcp: "0.5s", cls: "0.02", score: "98" },
            industry: "HVAC",
            color: "from-orange-500/30 to-[#0B1120]",
            tag: "Technical Precision"
        }
    ];

    const whatsappNumber = themeVariables.whatsappNumber || "447000000000";
    const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Hi SnapBilt! I saw your examples and I'd love to have my own demo site built for free.")}`;

    return (
        <section id="examples" className="py-24 bg-obsidian-light border-y border-white/5 relative overflow-hidden">
            {/* Heavy Grid Pattern Background */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
                <div className="text-center mb-16">
                    <h2 className="text-primary font-black uppercase tracking-[0.2em] text-sm mb-4 italic">Proof of Performance</h2>
                    <h3 className="text-3xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-tight">
                        See the <span className="text-primary">Difference</span>
                    </h3>
                    <p className="mt-4 text-neutral-dark font-medium max-w-2xl mx-auto">
                        High-performance assets built for elite contractors. Explore the speed, authority, and conversion architecture.
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8 mb-16">
                    {demos.map((demo, index) => (
                        <Link
                            key={index}
                            to={demo.path}
                            className="group relative bg-obsidian rounded-3xl overflow-hidden border border-white/5 hover:border-primary/40 transition-all shadow-2xl block"
                        >
                            {/* Preview Area */}
                            <div className={`aspect-video bg-gradient-to-br ${demo.color} relative flex items-center justify-center p-8 overflow-hidden`}>
                                <div className="absolute inset-0 bg-neutral-dark/10 group-hover:bg-transparent transition-colors"></div>

                                {/* Mock Browser UI */}
                                <div className="bg-obsidian/80 backdrop-blur-md p-4 rounded-xl border border-white/10 transform group-hover:scale-105 transition-transform shadow-xl w-full max-w-[200px]">
                                    <div className="flex gap-1 mb-3">
                                        <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
                                        <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
                                        <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
                                    </div>
                                    <div className="w-full h-2 bg-white/10 rounded-full mb-2"></div>
                                    <div className="w-2/3 h-2 bg-white/5 rounded-full"></div>
                                </div>

                                {/* Industry Tag */}
                                <div className="absolute top-4 left-4 bg-obsidian/80 backdrop-blur text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-white/10">
                                    {demo.industry}
                                </div>

                                {/* Feature Tag */}
                                <div className="absolute top-4 right-4 bg-primary/20 text-primary text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded border border-primary/30">
                                    {demo.tag}
                                </div>
                            </div>

                            {/* Data Strip */}
                            <div className="p-6 border-t border-white/5">
                                <div className="flex items-center justify-between mb-4">
                                    <h4 className="text-white font-black uppercase italic tracking-tight">{demo.name}</h4>
                                    <ExternalLink className="text-neutral-dark group-hover:text-primary transition-colors" size={18} />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-white/5 p-3 rounded-2xl border border-white/5 flex items-center gap-2">
                                        <Gauge className="text-accent h-4 w-4" />
                                        <div>
                                            <p className="text-[8px] text-neutral-dark font-black uppercase tracking-tighter">Speed</p>
                                            <p className="text-xs text-white font-black">{demo.speed}</p>
                                        </div>
                                    </div>
                                    <div className="bg-white/5 p-3 rounded-2xl border border-white/5 flex items-center gap-2">
                                        <Star className="text-orange-500 h-4 w-4 fill-current" />
                                        <div>
                                            <p className="text-[8px] text-neutral-dark font-black uppercase tracking-tighter">Authority</p>
                                            <p className="text-xs text-white font-black">{demo.reviews}+ Reviews</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-4">
                                    <div className="flex gap-4">
                                        <div>
                                            <p className="text-[7px] text-neutral-dark font-black uppercase tracking-widest">LCP</p>
                                            <p className="text-[10px] text-accent font-mono">{demo.vitals.lcp}</p>
                                        </div>
                                        <div>
                                            <p className="text-[7px] text-neutral-dark font-black uppercase tracking-widest">CLS</p>
                                            <p className="text-[10px] text-accent font-mono">{demo.vitals.cls}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-8 h-8 rounded-full border border-accent/30 flex items-center justify-center">
                                            <span className="text-[10px] font-black text-accent italic">{demo.vitals.score}</span>
                                        </div>
                                        <p className="text-[7px] text-neutral-dark font-black uppercase tracking-widest">Perf. Score</p>
                                    </div>
                                </div>
                            </div>

                            {/* Hidden Hover CTA */}
                            <div className="absolute inset-x-0 bottom-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform py-3 flex items-center justify-center gap-2 cursor-pointer">
                                <span className="text-obsidian font-black uppercase italic text-sm tracking-tight">Open Live Demo</span>
                                <MousePointer2 className="text-obsidian w-4 h-4 fill-current" />
                            </div>
                        </Link>
                    ))}
                </div>

                <div className="text-center">
                    <h4 className="text-white font-black mb-6 uppercase italic tracking-widest opacity-50">Want to see YOURS built like this?</h4>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                        <a
                            href={whatsappLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-primary hover:bg-white text-obsidian px-10 py-5 rounded-2xl font-black text-xl transition-all shadow-2xl shadow-primary/20 hover:-translate-y-1 uppercase italic tracking-tight flex items-center gap-3"
                        >
                            Build My Demo Site (Free)
                            <MousePointer2 className="fill-current w-6 h-6" />
                        </a>
                        <p className="text-neutral-dark font-mono text-xs max-w-[200px] text-center sm:text-left italic">
                            * No credit card required. 72-hour delivery window.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Examples;
