import React from 'react';
import { Zap, Gauge, Flame, CheckCircle2 } from 'lucide-react';
import { CONTACT_LINKS } from '../config/constants';

const Solution = () => {
    const steps = [
        { day: "Day 0", task: "We build your demo site using existing data." },
        { day: "Day 1", task: "You receive the Loom video comparison." },
        { day: "Day 2", task: "You click 'Claim Now' via WhatsApp." },
        { day: "Day 3", task: "Your precision site goes live." }
    ];

    return (
        <section id="how-it-works" className="py-24 bg-obsidian relative overflow-hidden">
            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full -z-10 pointer-events-none">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[60%] h-[60%] bg-accent/10 rounded-full blur-[120px]"></div>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                    <h2 className="text-accent font-black uppercase tracking-[0.2em] text-sm mb-4 italic">The SnapBilt Way</h2>
                    <h3 className="text-3xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-tight">
                        The <span className="text-accent">72-Hour</span> Precision Build
                    </h3>
                    <p className="mt-4 text-neutral-dark font-medium max-w-2xl mx-auto">
                        We don't do "Web Design." We provide a weaponize-able digital asset that converts leads while you sleep.
                    </p>
                </div>

                {/* 3-Column Feature Grid */}
                <div className="grid lg:grid-cols-3 gap-8 mb-20">
                    <div className="bg-obsidian-light p-8 rounded-[2rem] border border-white/5 relative group hover:border-accent/30 transition-all">
                        <Zap className="text-accent w-12 h-12 mb-6" strokeWidth={3} />
                        <h4 className="text-2xl font-black text-white uppercase italic mb-4 tracking-tight">Authority-First</h4>
                        <p className="text-neutral-dark font-medium leading-relaxed">
                            We auto-import your 5-star reviews, project photos, and accreditation badges. Your site starts with instant trust.
                        </p>
                    </div>

                    <div className="bg-obsidian-light p-8 rounded-[2rem] border border-white/5 relative group hover:border-accent/30 transition-all">
                        <Gauge className="text-accent w-12 h-12 mb-6" strokeWidth={3} />
                        <h4 className="text-2xl font-black text-white uppercase italic mb-4 tracking-tight">Sub-1s Speed</h4>
                        <p className="text-neutral-dark font-medium leading-relaxed">
                            Optimized for Core Web Vitals. Our sites load in under 1 second. Fast sites win jobs. Slow sites lose money.
                        </p>
                    </div>

                    <div className="bg-obsidian-light p-8 rounded-[2rem] border border-white/5 relative group hover:border-accent/30 transition-all">
                        <Flame className="text-accent w-12 h-12 mb-6" strokeWidth={3} />
                        <h4 className="text-2xl font-black text-white uppercase italic mb-4 tracking-tight">Zero Friction</h4>
                        <p className="text-neutral-dark font-medium leading-relaxed">
                            We build the draft FIRST before we even talk to you. No discovery calls. No placeholder content. Just your business, elevated.
                        </p>
                    </div>
                </div>

                {/* Timeline Section */}
                <div className="relative">
                    <h4 className="text-center text-white font-black uppercase italic mb-12 tracking-widest text-xl">The Sprint Timeline</h4>

                    <div className="grid md:grid-cols-4 gap-4 relative">
                        {/* Connecting Line (Desktop) */}
                        <div className="hidden md:block absolute top-[28px] left-[10%] right-[10%] h-0.5 bg-white/5 -z-10"></div>

                        {steps.map((step, index) => (
                            <div key={index} className="text-center">
                                <div className="w-14 h-14 bg-obsidian border-2 border-accent rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                                    <span className="text-accent font-black font-mono">{index}</span>
                                </div>
                                <h5 className="text-primary font-black uppercase italic text-sm mb-2">{step.day}</h5>
                                <p className="text-white font-bold leading-tight uppercase tracking-tight text-xs lg:text-sm px-4">
                                    {step.task}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="mt-20 text-center">
                    <div className="inline-flex items-center gap-3 bg-accent/10 border border-accent/20 px-6 py-3 rounded-2xl mb-8">
                        <CheckCircle2 className="text-accent h-5 w-5" />
                        <span className="text-white font-black uppercase italic tracking-tighter text-sm">Deployment Ready in 72 Hours</span>
                    </div>
                    <div className="flex justify-center">
                        <a
                            href={CONTACT_LINKS.WHATSAPP("I'm ready to start my 72-hour build! Let's discuss my project.")}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-accent hover:bg-white text-obsidian px-12 py-6 rounded-2xl font-black text-2xl transition-all shadow-2xl shadow-accent/20 hover:-translate-y-1 uppercase italic tracking-tight flex items-center gap-3"
                        >
                            Start My Build
                            <Zap className="fill-current w-6 h-6" />
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Solution;
