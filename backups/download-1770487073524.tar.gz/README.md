# SnapBilt — Internal Strategy Document

**For SnapBilt Team Members Only**

---

## The Core Strategy

### 1. The Mission: SnapBilt

SnapBilt provides **"Digital Assets for Elite Contractors."** We bridge the **Legitimacy Gap** for established tradespeople who have high-end physical reputations (570+ reviews, premium fleets) but underperforming digital presences (outdated sites, slow load times, directory dependence).

### 2. The Problem: The "Directory Tax" & Lead Dilution

**The Trap:** Top-tier roofers (Whale Leads) rely on directories like Checkatrade. These platforms send one lead to 3-5 competitors, forcing a "race to the bottom" on price.

**The Loss:** High-end clients doing "Deep Research" see a basic website and lose trust, assuming the contractor is a "two blokes in a van" operation.

**The Friction:** Traditional agencies take 4–8 weeks and £5,000+ for a custom build. Contractors are too busy for "discovery calls" and endless revisions.

### 3. The Solution: The "72-Hour Precision Build"

We replace **"Web Design"** (a service) with **"SnapBilt"** (a product).

- **Authority-First:** Sites built for conversion, speed (under 1s), and trust.
- **Fixed Window:** 72 hours from "Claim" to "Go-Live."
- **Zero Friction:** We build the draft first using our ContractorHub template, populating it with their actual reviews and project photos before we even talk to them.

### 4. Target Market: The "Goldilocks" Zone

- **Primary Niche:** UK Roofing (expanding to Solar/HVAC/Landscaping).
- **Tier 1 Prospects:** Established contractors (100+ reviews, VAT registered) with outdated or underperforming digital presence.
- **Geography:** High-value UK regions (London, Surrey, South East).

---

## Operations & Sales Architecture

### 5. The Productized Specs (Fixed Offer)

| Feature         | The SnapBilt Standard                                      |
| --------------- | ---------------------------------------------------------- |
| **Price Point** | £2,500 – £4,000 (One-time) + £30/mo (Optional hosting)     |
| **Delivery**    | 72-Hour Sprint (High-precision deployment)                 |
| **Tech Stack**  | Optimized for Core Web Vitals (Mobile-first, Instant Load) |
| **The Hook**    | Subdomain Demo: `prospect.snapbilt.co.uk`                  |

### 6. The Sales Loop (The "Build-First" Process)

1. **Inbound Request:** Contractor initiates contact via WhatsApp/Email requesting a demo site.
2. **Demo Build:** We create a high-quality draft on a subdomain using their Checkatrade reviews and photos (48 hours).
3. **Video Walkthrough:** Send a 2-minute Loom Video showing their new SnapBilt site with speed metrics and conversion features.
4. **Decision Point:** Contractor reviews and decides. If they claim it, the 72-hour full build sprint begins.
5. **Go Live:** "Site deployed to your domain. You own everything. Handover complete." (SMS/WhatsApp communication only, no Zoom calls).

### 7. Unit Economics & ROI

- **Price:** £2,500 (~€3,000)
- **Cost of Goods (COGS):** Minimal (Domain, Hosting, Template, AI tools)
- **Net Margin:** High efficiency due to productized precision builds and streamlined UK operations.
- **The "One Job" ROI:** A single re-roofing lead (£15k+) pays for the site 6x over. This is the core sales anchor.

### 8. Growth & Expansion

- **Phase 1 (Now):** Master the UK Roofing market with established contractors.
- **Phase 2 (Year 1):** Automate the data-scraping (reviews/images) to scale subdomain creation.
- **Phase 3 (Expansion):** Pivot brand to SnapBilt.eu for Solar/HVAC across Europe.

---

## Tech Stack

This application is built with:

- **React 19** + **Vite** (Fast build & HMR)
- **Tailwind CSS** (Rapid UI development with custom industrial theme)
- **React Router DOM** (Multi-page navigation)
- **Lucide React** (Icon library)
- **PostCSS** (Tailwind processing)

### Current Implementation Status

#### ✅ Completed Features

**Pages:**

- **Homepage (`/`)**: Full landing page with Hero, Problem, Solution, Examples, Pricing, and Contact sections
- **How It Works (`/how-it-works`)**: Detailed process breakdown with FAQ accordion

**Components:**

- `Navbar.jsx` - Fixed navigation with smart routing (hash links + page navigation)
- `Hero.jsx` - Split-screen "Zombie vs SnapBilt" comparison with industrial aesthetics
- `Problem.jsx` - "Directory Tax" pain point visualization
- `Solution.jsx` - 72-Hour Sprint timeline and feature grid
- `Examples.jsx` - Live subdomain demo cards with speed metrics
- `Pricing.jsx` - Interactive ROI calculator and pricing card
- `Contact.jsx` - WhatsApp-first CTA with trust badges and footer
- `ScrollToTop.jsx` - Floating scroll-to-top button with industrial orange styling
- `ScrollToTopOnNavigate.jsx` - Auto-scroll on route changes

**Design System:**

- **Industrial Aesthetic Theme**
  - Safety Orange (#FF5F1F) - Primary CTA color
  - Obsidian (#0B0B0B) - Background
  - Accent Green (#10B981) - Success/ROI indicators
  - Alert Red (#EF4444) - Problem/urgency
- **Typography**: Inter (body) + JetBrains Mono (technical elements)
- **Animations**: Subtle hover effects, transitions, and industrial precision

### Development

```bash
npm install      # Install dependencies
npm run dev      # Start development server (http://localhost:5173)
npm run build    # Production build
npm run preview  # Preview production build
npm run lint     # Run ESLint
```

### Project Structure

```
src/
├── components/
│   ├── Contact.jsx          # Final CTA + Footer
│   ├── Examples.jsx         # Live demo subdomains
│   ├── Hero.jsx             # Landing hero section
│   ├── Home.jsx             # Homepage container
│   ├── HowItWorks.jsx       # Process explanation page
│   ├── Navbar.jsx           # Fixed navigation
│   ├── Pricing.jsx          # ROI calculator + pricing
│   ├── Problem.jsx          # "Directory Tax" section
│   ├── ScrollToTop.jsx      # Floating button
│   ├── ScrollToTopOnNavigate.jsx  # Route change handler
│   └── Solution.jsx         # 72-Hour Sprint timeline
├── App.jsx                  # Router configuration
├── main.jsx                 # React entry point
├── index.css                # Global styles + Tailwind
└── App.css                  # Component styles
```
