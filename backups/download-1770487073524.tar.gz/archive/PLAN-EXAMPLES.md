# Plan: Three High-Converting Contractor Example Sites [READY]

Build three production-ready contractor websites (Roofing, HVAC, Solar) as live proof-of-concept demos that showcase SnapBilt's "72-hour precision build" promise. Each site will follow the established design system, emphasize immediate CTAs, and deliver sub-1s load speeds while targeting UK contractors.

## Status: READY
Completed on 2026-01-31

## Implementation Checklist

- [x] **Step 1:** Create three separate contractor site projects (Implemented as Routes)
- [x] **Step 2:** Design industry-specific Hero sections
- [x] **Step 3:** Source or create visual assets (Placeholder gradients/icons used)
- [x] **Step 4:** Deploy all three sites to live subdomains (Internal routes active)
- [x] **Step 5:** Update Examples.jsx
- [x] **Step 6:** Add visual differentiation (Roofing: Slate Gray + Terracotta, Solar: Emerald, HVAC: Navy + Orange)
- [x] **Step 7:** Add demo transparency banners to all example sites
- [x] **Step 8:** Add interactive graphics (Roofing: Integrity Index, Solar: ROI Calculator, HVAC: System Dashboard)

---

## Steps

### 1. Create three separate contractor site projects

Using the current SnapBilt tech stack (React + Vite + Tailwind + lucide-react). Each site gets its own folder structure with industry-specific content:

- **Apex Roofing** (`examples/apex-roofing`)
- **Surrey Solar** (`examples/surrey-solar`)
- **Elite HVAC London** (`examples/elite-hvac`)

Structure each with:

- Hero (contractor-specific headline + WhatsApp CTA)
- Services (3-4 main offerings)
- Reviews showcase
- Contact section with prominent phone/WhatsApp
- Minimal About section

### 2. Design industry-specific Hero sections

With immediate conversion focus:

**Roofers:**

- Headline: "Emergency Repairs Within 4 Hours"
- CTA: "Get Free Quote"
- Accent: Slate Gray (#1e293b) + Burnt Orange/Brick (#9a3412) — evokes professional roofing materials and high-end craftsmanship.

**Solar:**

- Headline: "Calculate Your Savings"
- Widget: ROI calculator
- CTA: "Free Site Assessment"
- Accent: Green (eco-friendly, savings)

**HVAC:**

- Headline: "24/7 Emergency Service"
- CTA: "Book Service Call"
- Accent: Blue/Red (heating/cooling)

Each uses:

- Safety Orange (#FF5F1F) for primary CTAs
- Obsidian (#0B0B0B) backgrounds
- Industry-specific accent colors

### 3. Source or create visual assets

For each trade:

**Images:**

- High-quality stock from Unsplash/Pexels (rooftop work, solar installations, HVAC units)
- OR placeholder gradients with industry icons from lucide-react:
  - `Hammer` (Roofing)
  - `Sun`, `Zap` (Solar)
  - `Wind`, `Wrench` (HVAC)

**Trust Badges (UK-specific):**

- Checkatrade (all trades)
- Gas Safe Register (HVAC)
- MCS certification (Solar)
- NFRC (Roofing)

Store optimized WebP images in each project's `/public/images/` folder.

### 4. Deploy all three sites to live subdomains

Using Vercel or Netlify:

- apex-roofing.snapbilt.co.uk
- surrey-solar.snapbilt.co.uk
- elite-hvac.snapbilt.co.uk

**Performance validation:**

- Run Lighthouse audits to verify sub-1s load times
- Capture desktop + mobile screenshots using Playwright or DevTools
- Save to `public/examples/` folder as WebP format

### 5. Update Examples.jsx

Replace gradient placeholders with real content:

- Add real screenshots from deployed sites
- Link cards to live subdomain URLs
- Add performance metrics (Lighthouse scores)
- Add conversion labels ("3 WhatsApp leads/day")
- Refine hover states: "View Live Demo →" with working external links

---

## Further Considerations

### 1. Content depth

**Question:** Should each example be a full multi-page site (Home, Services, About, Contact) or a high-converting single-page layout?

**Recommendation:** Single-page would be faster to build and emphasizes the "72-hour" speed promise.

**Decision:** Single-page routes within the main app.

---

### 2. Real vs. placeholder data

**Question:** Use fictional company details (reviews, project photos, service areas) or scrape real contractor data from Checkatrade for authenticity?

**Recommendation:** Fictional is safer legally but less convincing. Consider hybrid approach: real review structure with modified names/details.

**Decision:** Hybrid. Authentic UK contractor feel with modified names.

---

### 3. Screenshot vs. live embed

**Question:** Show static screenshots in Examples.jsx cards, or use iframe embeds that load the live site on hover/click?

**Trade-offs:**

- Screenshots: Faster page load, better UX
- Iframes: Proves the site works live, but may slow Examples page

**Recommendation:** Static screenshots with "Open Live Demo" button linking to actual subdomain.

**Decision:** Static screenshots in main site, linking to live routes.

---

### 4. Phone numbers and WhatsApp

**Question:** Use a real SnapBilt contact number that routes to you, or placeholder numbers (e.g., 07000 000000) that clearly indicate "demo mode"?

**Options:**

- **Real number:** Captures actual leads from examples
- **Placeholder:** Clearly indicates demo status, no confusion

**Recommendation:** Use real number with pre-filled WhatsApp message indicating "I saw your example site" to track source.

**Decision:** Real number with industry-specific pre-filled messages.

---

## Technical Requirements

### Tech Stack (per example site)

- React 18+
- Vite (build tool)
- Tailwind CSS 3
- lucide-react (icons)
- React Router (if multi-page)

### Performance Targets

- **Load Time:** Sub-1 second (verified via Lighthouse)
- **Mobile Score:** 95+ (Lighthouse Performance)
- **SEO Score:** 90+ (Lighthouse SEO)
- **Accessibility:** 90+ (Lighthouse Accessibility)

### Design System Alignment

- Use SnapBilt color palette (Primary Orange, Obsidian backgrounds)
- Inter font (headings, body)
- JetBrains Mono (technical details, metrics)
- Consistent CTA styling (rounded-2xl, shadow-2xl, uppercase italic)
- lucide-react icons only

---

## Content Strategy Per Industry

### Roofing (Apex Roofing Specialists)

**Services:**

- Emergency Roof Repairs
- New Roof Installations
- Flat Roofing
- Guttering & Fascias

**Tone:** Authority, reliability, emergency-ready

**Key Messages:**

- "24/7 Emergency Response"
- "Insurance Work Specialists"
- "20+ Years Experience"

**CTAs:**

- Primary: "Get Emergency Quote"
- Secondary: "Book Free Survey"

---

### Solar (Surrey Solar Solutions)

**Services:**

- Solar Panel Installation
- Battery Storage Systems
- Government Grant Applications
- Annual Maintenance

**Tone:** Future-focused, savings-oriented, eco-friendly

**Key Messages:**

- "Save £800+/year on energy"
- "£0 upfront with finance"
- "MCS Certified Installers"

**CTAs:**

- Primary: "Calculate My Savings" (widget)
- Secondary: "Free Site Assessment"

---

### HVAC (Elite HVAC London)

**Services:**

- Boiler Installation & Replacement
- Air Conditioning Installation
- Heating System Repairs
- Annual Service Plans

**Tone:** Comfort, efficiency, year-round service

**Key Messages:**

- "Gas Safe Registered Engineers"
- "Same-Day Emergency Service"
- "10-Year Warranty"

**CTAs:**

- Primary: "Book Service Call"
- Secondary: "Emergency Repairs 24/7"

---

## Success Criteria

- [x] All three sites deployed to live subdomains (Internal routes)
- [x] Sub-1s load times verified (Lighthouse)
- [x] Mobile-responsive on all devices
- [x] WhatsApp CTAs functional with pre-filled messages
- [ ] Screenshots captured and integrated into Examples.jsx (Using internal route links)
- [x] Each site demonstrates different industry approach
- [x] Trust badges and certifications displayed
- [x] Performance metrics visible (speed, reviews)
- [x] Demo banners added for transparency
- [x] Industry-specific interactive features (Integrity Index, ROI Calculator, System Dashboard)

---

## Next Steps

1. **Answer the 4 "Further Considerations" questions** to finalize scope
2. **Set up project structure** (separate folders or monorepo?)
3. **Begin with one example** (recommend Roofing as simplest)
4. **Deploy and validate** before building remaining two
5. **Update Examples.jsx** once all three are live

---

## Apex Roofing Enhancement Strategy

### Critical Missing Element: Visual Proof of Work

**Problem:** Current Apex Roofing site lacks the #1 conversion driver for contractors: **tangible proof of finished work**. Roofers browsing the demo need to visualize _their_ business through completed projects.

**Goal:** Make contractors say "I want that!" by showcasing transformation, craftsmanship, and professionalism through compelling visual storytelling.

---

### Phase 1: Project Gallery (Week 1 — Highest Impact)

**1.1 Before/After Showcase**

- **Implementation:** Dedicated "Recent Projects" section after Services
- **Format:** 2-column grid (mobile: single column)
- **Features:**
  - Interactive image slider (drag or click to reveal "after")
  - Overlay with project details on hover:
    - Project type (e.g., "Victorian Slate Restoration")
    - Location (e.g., "Woking, Surrey")
    - Completion time (e.g., "3-day installation")
    - Price range indicator (£££ system or "From £4,500")
  - "View Full Gallery" CTA at bottom

**Content Strategy:**

- **Primary Option:** Generate custom images using **Gemini 2026 nano banan pro**
  - Prompts: "Professional UK roofing installation, slate roof, before and after, photorealistic, construction site"
  - Benefits: Fully customizable, consistent style, no licensing concerns, UK-specific aesthetics
  - Generate pairs: damaged/worn roof (before) + pristine new installation (after)
- **Alternative:** High-quality stock images from Unsplash/Pexels if AI generation unavailable
- Categories: Slate restoration, emergency repairs, new builds, flat roofing
- AI Prompt examples:
  - "Victorian terraced house with damaged slate roof, UK architecture, overcast weather, realistic photo"
  - "Newly installed premium slate roof on UK home, professional finish, sunny day, high quality photo"
  - "Emergency roof tarp covering storm damage, residential UK property, dramatic lighting"
  - "Modern flat EPDM roof installation complete, commercial building, clean professional finish"

**Technical:**

```javascript
// Component structure
<section className="py-24 bg-slate-900">
  <ProjectGallery
    projects={[
      {
        before: "/images/projects/roof-1-before.webp",
        after: "/images/projects/roof-1-after.webp",
        title: "Emergency Storm Damage Repair",
        location: "Guildford",
        duration: "Same-day fix",
        category: "Emergency",
      },
    ]}
  />
</section>
```

---

**1.2 Filterable Project Categories**

- **Tabs:** All | Emergency Repairs | New Installations | Slate & Tile | Flat Roofing
- **Interaction:** Click to filter gallery dynamically
- **Benefit:** Shows versatility and specialization

---

**1.3 Project Detail Cards**
Instead of plain images, wrap each in a card with:

- Material used badge (e.g., "Premium Welsh Slate")
- Client quote snippet ("Transformed our 1920s home")
- Warranty indicator (e.g., "25-Year Guarantee")

---

### Phase 2: Video Integration (Week 2 — Emotional Impact)

**2.1 Hero Video Background**

- **Format:** Looping 10-15s clip of roofers working (muted, subtle overlay)
- **Alternative:** Replace Integrity Index with video testimonial card
- **Sources:** Pexels Videos, Coverr.co (search: "construction worker", "roof repair")

**2.2 Customer Testimonial Videos**

- **Placement:** Between Reviews and CTA sections
- **Format:** 30-60s clips with professional overlays
- **Fallback:** Use stock + voiceover initially, structure for real testimonials later
- **Technical:** Embed YouTube/Vimeo with custom thumbnail

**2.3 Time-Lapse Installation**

- **Concept:** "Watch a Complete Roof Install in 60 Seconds"
- **Emotional Hook:** Shows speed, professionalism, crew coordination
- **CTA:** "See Your Project Come to Life — Get Quote"

---

### Phase 3: Interactive Trust Elements (Week 2-3)

**3.1 Live Project Counter**

- **Display:** Animated number counting up
- **Text:** "Projects Completed in 2026: 127" (increments on page load)
- **Placement:** Credibility Strip section

**3.2 Real-Time Review Feed**

- **Concept:** Rotating carousel of recent Checkatrade reviews
- **Format:** Small cards with star rating, excerpt, date
- **Animation:** Fade in/out every 8 seconds
- **Example:**
  ```
  ⭐⭐⭐⭐⭐ "Exceptional service..."
  Sarah M., Woking • 2 days ago
  ```

**3.3 Accreditation Badge Wall**

- **Current State:** Trust badges mentioned but not visually present
- **Enhancement:** Add logo grid after hero:
  - Checkatrade Approved
  - CompetentRoofer Certified
  - TrustMark Registered
  - Public Liability Insured (£5M)
  - 25-Year Guarantee Seal
- **Format:** Grayscale logos with hover color pop

**3.4 Team Photos**

- **Concept:** "Meet the Master Roofers" micro-section
- **Format:** 3-4 circular headshots with names/titles
- **Benefit:** Humanizes brand, builds trust
- **Stock Alternative:** Use diverse construction worker portraits from Unsplash

---

### Phase 4: Advanced Interactive Features (Week 3-4)

**4.1 3D Roof Visualizer (Aspirational)**

- **Concept:** Upload house photo → AI overlays new roof style
- **Simpler Alternative:** Static comparison grid:
  - "Your Roof Could Look Like This"
  - 4 house styles (Victorian, Modern, Cottage, Semi-Detached)
  - Clickable to see different roof materials applied

**4.2 Material Comparison Tool**

- **Format:** Side-by-side table
- **Columns:** Slate vs Tile vs Flat EPDM
- **Rows:** Lifespan, Cost, Maintenance, Appearance
- **Interactive:** Hover highlights winner in each category

**4.3 Warranty Calculator**

- **Input:** Roof type, material, installation year
- **Output:** "Your roof is covered until 2049 — 23 years remaining"
- **CTA:** "Transfer warranty to new owner? Contact us"

**4.4 Emergency Response Map**

- **Visual:** Live map showing Surrey coverage zones
- **Data Points:** Current crew locations (anonymized)
- **Text:** "3 crews active in your area — 4-hour response guaranteed"

---

### Phase 5: Content Enhancements

**5.1 Process Transparency Section**

- **Title:** "How We Transform Your Roof in 5 Days"
- **Format:** Vertical timeline with icons
- **Steps:**
  1. Free Survey & Quote (Day 0)
  2. Materials Ordered (Day 1)
  3. Scaffolding & Prep (Day 2)
  4. Installation (Days 3-4)
  5. Final Inspection & Cleanup (Day 5)
- **Visual:** Progress bar showing typical project duration

**5.2 Problem/Solution Scenarios**

- **Format:** Icon + headline + solution
- **Examples:**
  - "Leaking Ceiling? → Same-day Emergency Patch"
  - "Insurance Claim? → We Handle All Paperwork"
  - "Listed Building? → Heritage Slate Specialists"

**5.3 Seasonal Messaging**

- **Winter:** "Storm Damage Repairs — 4-Hour Callout"
- **Spring:** "Spring Roof Health Check — £99"
- **Summer:** "Beat the Winter Rush — Book Now"

---

### Implementation Priority

**Week 1 (Must-Have):**

1. ✅ Project gallery with 6-9 before/after images
2. ✅ Filterable categories (Emergency, Installation, Slate, Flat)
3. ✅ Accreditation badge wall
4. ✅ Process timeline section

**Week 2 (High-Impact):**

1. Video testimonial section
2. Live review feed
3. Team photos
4. Material comparison tool

**Week 3 (Nice-to-Have):**

1. Hero video background
2. Time-lapse installation
3. Roof style visualizer (static version)
4. Emergency response map

**Week 4 (Polish):**

1. Warranty calculator
2. Seasonal messaging system
3. 3D visualizer prototype (if feasible)

---

### Technical Notes

**Image Optimization:**

- Convert all images to WebP format
- Implement lazy loading for gallery
- Use `loading="lazy"` attribute
- Compress images to <100KB each

**Performance Impact:**

- Gallery should not slow initial page load
- Use intersection observer for scroll-triggered animations
- Defer video loading until user scrolls to section

**Accessibility:**

- Alt text for all project images
- Keyboard navigation for gallery
- Screen reader announcements for live counters

**Image Generation & Sources:**

**Primary: Gemini 2026 nano banan pro**

- Generate 9-12 photorealistic project images (before/after pairs)
- Prompt templates:
  - Before: "[roof type] damaged/worn roof on [UK house style], realistic photography, overcast UK weather"
  - After: "professionally installed [roof type] on [UK house style], pristine finish, natural lighting, photorealistic"
- Style consistency: "professional construction photography, 4K quality, natural lighting, UK residential architecture"
- Output format: High-res PNG → convert to WebP for web

**Fallback Stock Sources:**

- Unsplash Collections: Construction, Architecture, Home Renovation
- Pexels: "roof repair", "construction worker UK"
- Coverr.co: Construction/Architecture videos (free, no attribution)

**AI Generation Workflow:**

1. Define 6 project categories (emergency, slate, tile, flat, Victorian, modern)
2. Generate before/after pairs per category using Gemini
3. Post-process: color grade for consistency, add subtle vignette
4. Compress to WebP (<100KB each)
5. Store in `/public/images/projects/`

---

### Success Metrics

**Engagement Indicators:**

- Time spent on gallery section (target: 45+ seconds)
- Click-through rate on "View Project Details"
- Video play rate (target: 60%+)
- CTA conversions after viewing gallery vs before

**Contractor Feedback:**

- "I want this exact layout" mentions
- Screenshot/sharing behavior
- WhatsApp message volume increase

**Performance:**

- Maintain sub-1s load time
- Gallery section loads in <500ms
- Zero CLS (Cumulative Layout Shift) from images

---

### Long-Term Vision

**User-Generated Content Integration:**

- Allow contractors to upload their own project photos
- Auto-populate gallery from Google Business Profile
- Integrate with Checkatrade API for real reviews

**AI Enhancements:**

- **Gemini 2026 nano banan pro:** Generate photorealistic project gallery images on-demand
- ChatGPT-powered quote estimator
- AI roof damage assessment from uploaded photos (using Gemini vision)
- Automated seasonal messaging based on weather data
- AI-generated team photos and trust badges if needed

**Advanced Features:**

- AR roof preview (smartphone camera overlay)
- Drone footage integration
- Live installation webcam for current projects
