import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: path.resolve(__dirname, '../../framework/Source/themes/snapbilt-theme/ui'),
    emptyOutDir: true,
    lib: {
      entry: path.resolve(__dirname, 'src/index.jsx'),
      name: 'SnapbiltTheme',
      fileName: () => 'bundle.js',
      formats: ['es']
    },
    rollupOptions: {
      external: ['react', 'react-dom', 'lucide-react', 'react-router-dom', '@fromcode/react'],
      output: {
        assetFileNames: (assetInfo) => {
          if (assetInfo.name === 'style.css') return 'theme.css';
          return assetInfo.name;
        },
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM'
        }
      }
    }
  },
  server: {
    host: true,
  },
  preview: {
    host: true,
  }
})
