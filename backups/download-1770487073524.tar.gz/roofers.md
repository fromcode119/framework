# Mobile Performance Audit (Lighthouse/PageSpeed)

Evaluation based on full Lighthouse **Mobile** performance audits (matching PageSpeed Insights).

## Methodology

The testing is performed using the Lighthouse CLI with the following parameters to ensure parity with Google PageSpeed Insights:

- **Form Factor**: `mobile`
- **Throttling**: Simulated 4G (Slow) / Moto G Power emulation
- **Categories**: `performance`
- **Command**: `lighthouse <URL> --chrome-flags="--headless" --form-factor=mobile --only-categories=performance`

Our Baseline:
**SnapBilt Example (https://snapbilt.com/examples/roofing) - Very Good (98/100)**

---

## Target Leads

https://www.roofer-sutton.co.uk/ - Bad (46/100)
https://www.empireupvcandroofing.co.uk/ - Bad (32/100)
https://www.awhittakerroofingltd.co.uk/ - Average (55/100)
https://www.finestoneroofersanddecorators.co.uk/ - Very Bad (21/100)
https://www.rooftops-watford.co.uk/ - Bad (45/100)
https://www.aparkandhobbsroofing.co.uk/ - Very Bad (12/100)
https://www.jvincentroofinglimited.co.uk/ - Average (62/100)
https://www.kccs.co.uk/ - Bad (38/100)
https://www.edscaffolding.co.uk/ - Bad (41/100)
https://www.roofingsurreyandberkshire.co.uk/ - Average (58/100)
https://wiffenandsons.co.uk/ - Very Bad (29/100)
https://www.brunwinroofing.co.uk/ - Bad (44/100)
https://www.highverge.com/ - Bad (35/100)
https://www.owroofing.co.uk/ - Average (52/100)
https://www.coasttocoastroofing.co.uk/ - Bad (31/100)
https://www.alphasgl.co.uk/ - Bad (47/100)
https://www.brandonroofing.co.uk/ - Average (59/100)
https://www.mccollochroofing.co.uk/ - Average (68/100)
https://www.worldofroofing.co.uk/ - Very Bad (25/100)
https://www.londonroofingltd.com/ - Very Bad (19/100)
https://www.inlineroofingandbuilding.co.uk/ - Bad (43/100)
https://www.aldconstruction.co.uk/ - Average (54/100)
https://www.anrroofing.co.uk/ - Average (61/100)
