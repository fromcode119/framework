"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// plugins/cms/index.ts
var index_exports = {};
__export(index_exports, {
  default: () => index_default,
  onEnable: () => onEnable,
  onInit: () => onInit
});
module.exports = __toCommonJS(index_exports);

// plugins/cms/collections/Pages.ts
var Pages = {
  shortSlug: "pages",
  slug: "pages",
  type: "collection",
  versions: true,
  workflow: true,
  admin: {
    useAsTitle: "title",
    group: "Content",
    defaultColumns: ["title", "slug", "status", "updatedAt"],
    previewPrefixSettingsKey: "pagesPrefix"
  },
  fields: [
    {
      name: "title",
      type: "text",
      required: true,
      label: "Page Title"
    },
    {
      name: "slug",
      type: "text",
      required: true,
      unique: true,
      label: "Permalink"
    },
    {
      name: "customPermalink",
      type: "text",
      unique: true,
      admin: {
        position: "sidebar",
        description: "Override the global permalink structure for this specific entry."
      }
    },
    {
      name: "content",
      type: "json",
      label: "Content Blocks",
      admin: {
        component: "BlockEditor",
        description: "Build your page layout using modular blocks."
      }
    },
    {
      name: "scheduledPublishAt",
      type: "datetime",
      label: "Schedule Release",
      admin: {
        position: "sidebar",
        description: "Automatically set status to Published at this date/time."
      }
    },
    {
      name: "parent",
      type: "relationship",
      relationTo: "pages",
      admin: {
        position: "sidebar",
        component: "TagField",
        sourceCollection: "pages",
        sourceField: "slug",
        description: "Set a parent page to create a hierarchical URL structure."
      }
    },
    {
      name: "featured_image",
      type: "relationship",
      relationTo: "media",
      admin: {
        position: "sidebar",
        description: "Primary banner image for this page."
      }
    },
    {
      name: "template",
      type: "select",
      defaultValue: "default",
      options: [
        { label: "Default Template", value: "default" },
        { label: "Full Width Layout", value: "full-width" },
        { label: "Homepage Template", value: "home" },
        { label: "Landing Page", value: "landing" }
      ],
      admin: {
        position: "sidebar"
      }
    },
    {
      name: "themeLayout",
      type: "ui",
      label: "Theme Layout",
      admin: {
        position: "sidebar",
        component: "ThemeLayoutSelect"
      }
    }
  ]
};
var Pages_default = Pages;

// plugins/cms/collections/Posts.ts
var Posts = {
  shortSlug: "posts",
  slug: "posts",
  versions: true,
  workflow: true,
  admin: {
    useAsTitle: "title",
    group: "Content",
    previewPrefixSettingsKey: "postsPrefix"
  },
  fields: [
    {
      name: "title",
      type: "text",
      required: true
    },
    {
      name: "slug",
      type: "text",
      required: true,
      unique: true,
      admin: {
        description: "The URL-friendly slug used for the permalink."
      }
    },
    {
      name: "customPermalink",
      type: "text",
      unique: true,
      admin: {
        position: "sidebar",
        description: "Override the global permalink structure for this specific entry."
      }
    },
    {
      name: "featured_image",
      label: "Featured image",
      type: "relationship",
      relationTo: "media",
      admin: {
        position: "sidebar",
        description: "Primary banner image for the post."
      }
    },
    {
      name: "excerpt",
      type: "textarea",
      label: "Excerpt",
      admin: {
        description: "A short summary of the post used in archives and search results."
      }
    },
    {
      name: "content",
      type: "json",
      label: "Content Blocks",
      admin: {
        component: "BlockEditor",
        description: "Build your post using modular content blocks."
      }
    },
    {
      name: "author",
      type: "relationship",
      relationTo: "users",
      label: "Author",
      required: true,
      admin: {
        position: "sidebar",
        component: "TagField",
        sourceCollection: "users",
        sourceField: "username",
        description: "Select the primary author for this post."
      },
      hasMany: false
    },
    {
      name: "publishedAt",
      type: "datetime",
      label: "Publish Date",
      admin: {
        position: "sidebar",
        description: "Override the date display for this post."
      }
    },
    {
      name: "scheduledPublishAt",
      type: "datetime",
      label: "Schedule Release",
      admin: {
        position: "sidebar",
        description: "Automatically set status to Published at this date/time."
      }
    },
    {
      name: "categories",
      type: "relationship",
      relationTo: "categories",
      hasMany: true,
      admin: {
        component: "TagField",
        sourceCollection: "categories",
        sourceField: "slug",
        position: "sidebar"
      }
    },
    {
      name: "tags",
      type: "relationship",
      relationTo: "tags",
      hasMany: true,
      admin: {
        component: "TagField",
        sourceCollection: "tags",
        sourceField: "slug",
        position: "sidebar"
      }
    }
  ]
};
var Posts_default = Posts;

// plugins/cms/collections/Categories.ts
var Categories = {
  shortSlug: "categories",
  slug: "categories",
  admin: {
    useAsTitle: "name",
    group: "Content",
    previewPrefixSettingsKey: "categoriesPrefix"
  },
  fields: [
    {
      name: "name",
      type: "text",
      required: true
    },
    {
      name: "slug",
      type: "text",
      required: true,
      unique: true
    },
    {
      name: "description",
      type: "textarea",
      admin: {
        position: "sidebar",
        description: "A brief description of this category for SEO and context."
      }
    },
    {
      name: "color",
      type: "text",
      admin: {
        position: "sidebar",
        component: "ColorPicker",
        description: "Optional color for visual categorization in the UI."
      }
    },
    {
      name: "customPermalink",
      type: "text",
      unique: true,
      admin: {
        position: "sidebar",
        description: "Override the global permalink structure for this category."
      }
    },
    {
      name: "parent",
      type: "relationship",
      relationTo: "categories",
      admin: {
        position: "sidebar",
        component: "TagField",
        sourceCollection: "categories",
        sourceField: "slug",
        description: "Create a hierarchical structure for your categories."
      }
    },
    {
      name: "order",
      type: "number",
      defaultValue: 0,
      admin: {
        position: "sidebar"
      }
    }
  ]
};
var Categories_default = Categories;

// plugins/cms/collections/Tags.ts
var Tags = {
  shortSlug: "tags",
  slug: "tags",
  admin: {
    useAsTitle: "name",
    group: "Content",
    previewPrefixSettingsKey: "tagsPrefix"
  },
  fields: [
    {
      name: "name",
      type: "text",
      required: true
    },
    {
      name: "slug",
      type: "text",
      required: true,
      unique: true
    },
    {
      name: "description",
      type: "textarea",
      admin: {
        position: "sidebar",
        description: "A brief description of this tag for SEO and context."
      }
    },
    {
      name: "color",
      type: "text",
      admin: {
        position: "sidebar",
        component: "ColorPicker",
        description: "Optional color for visual categorization in the UI."
      }
    },
    {
      name: "order",
      type: "number",
      defaultValue: 0,
      admin: {
        position: "sidebar",
        description: "Display order (lower numbers appear first)."
      }
    },
    {
      name: "customPermalink",
      type: "text",
      unique: true,
      admin: {
        position: "sidebar",
        description: "Override the global permalink structure for this tag."
      }
    }
  ]
};
var Tags_default = Tags;

// plugins/cms/collections/Templates.ts
var Templates = {
  shortSlug: "templates",
  slug: "templates",
  type: "collection",
  admin: {
    useAsTitle: "title",
    group: "Design",
    defaultColumns: ["title", "category", "updatedAt"]
  },
  fields: [
    {
      name: "title",
      type: "text",
      required: true,
      label: "Template Name"
    },
    {
      name: "category",
      type: "select",
      options: [
        { label: "Hero Sections", value: "hero" },
        { label: "Content Sections", value: "content" },
        { label: "Features", value: "features" },
        { label: "Pricing", value: "pricing" },
        { label: "Team", value: "team" },
        { label: "Contact", value: "contact" },
        { label: "Global Sections", value: "global" }
      ],
      defaultValue: "content",
      admin: {
        position: "sidebar"
      }
    },
    {
      name: "blockData",
      type: "json",
      label: "Block Data",
      required: true
    },
    {
      name: "previewImage",
      type: "upload",
      relationTo: "media",
      label: "Preview Thumbnail"
    }
  ]
};
var Templates_default = Templates;

// plugins/cms/collections/Navigation.ts
var Navigation = {
  shortSlug: "navigation",
  slug: "navigation",
  type: "collection",
  admin: {
    useAsTitle: "name",
    group: "Content",
    icon: "Menu",
    defaultColumns: ["name", "slug", "updatedAt"],
    preview: false
  },
  fields: [
    {
      name: "name",
      type: "text",
      required: true,
      label: "Menu Name"
    },
    {
      name: "slug",
      type: "text",
      required: true,
      unique: true,
      label: "Menu Identifier"
    },
    {
      name: "items",
      type: "array",
      label: "Menu Items",
      fields: [
        {
          name: "label",
          type: "text",
          required: true
        },
        {
          name: "type",
          type: "select",
          defaultValue: "url",
          options: [
            { label: "Custom URL", value: "url" },
            { label: "Page", value: "page" },
            { label: "Post", value: "post" }
          ]
        },
        {
          name: "url",
          type: "text",
          required: true,
          admin: {
            condition: (data, siblingData) => siblingData?.type === "url"
          }
        },
        {
          name: "page",
          type: "relationship",
          relationTo: "pages",
          admin: {
            condition: (data, siblingData) => siblingData?.type === "page"
          }
        },
        {
          name: "post",
          type: "relationship",
          relationTo: "posts",
          admin: {
            condition: (data, siblingData) => siblingData?.type === "post"
          }
        },
        {
          name: "target",
          type: "select",
          options: [
            { label: "Same Tab", value: "_self" },
            { label: "New Tab", value: "_blank" }
          ],
          defaultValue: "_self"
        },
        {
          name: "priority",
          type: "number",
          defaultValue: 0
        }
      ]
    }
  ]
};
var Navigation_default = Navigation;

// plugins/cms/index.ts
var import_sdk = require("@fromcode/sdk");

// plugins/cms/i18n/en.json
var en_default = {
  dashboard: {
    intelligence: "CMS Dashboard",
    subtitle: "Manage your content and pages",
    view_all: "View All",
    new_post: "New Post",
    stats: {
      posts: "Posts",
      pages: "Pages",
      views: "Views",
      media: "Media"
    },
    recent_entries: "Recent Posts",
    live_feed: "Activity Log",
    void_detected: "No Content Found",
    void_description: "Start by creating your first post or page."
  },
  posts: {
    title: "Posts",
    description: "Create and manage your blog posts",
    add: "Add New Post",
    empty_title: "No Posts Found",
    empty_description: "Create your first post to see it here."
  },
  pages: {
    title: "Pages",
    description: "Manage your website pages",
    add: "Add New Page",
    empty_title: "No Pages Found",
    empty_description: "Create your first page to get started."
  },
  categories: {
    title: "Categories",
    description: "Organize your posts into categories",
    add: "Add Category",
    empty_title: "No Categories",
    empty_description: "Create categories to organize your content."
  },
  tags: {
    title: "Tags",
    description: "Label your posts with tags",
    add: "Add Tag",
    empty_title: "No Tags",
    empty_description: "Define tags for better content discovery."
  },
  navigation: {
    title: "Menus",
    description: "Create and customize your site navigation",
    add: "Add Menu",
    empty_title: "No Menus Found",
    empty_description: "Create your first menu to define site navigation."
  },
  common: {
    records: "Items",
    loading: "Loading..."
  },
  renderer: {
    empty_collection: "Collection contains 0 blocks",
    corrupt_data: "Invalid block data detected",
    missing: "Renderer Missing",
    object_error: "Data structure error",
    classic_fallback: "Classic Content Fallback",
    no_content: "No Content Available"
  },
  table: {
    title: "Name",
    status: "Status",
    date: "Date",
    slug: "Slug/Path",
    updated: "Last Updated",
    designation: "Name",
    count: "Total Items"
  },
  status: {
    published: "Published",
    draft: "Draft",
    archived: "Archived"
  },
  media: {
    vault_title: "Media Library",
    vault_description: "Browse and select assets for your project",
    search_placeholder: "Search files...",
    upload: "Upload",
    accessing_vault: "Loading Library...",
    no_assets: "No assets found",
    no_assets_description: "Try searching for something else or upload a new file below.",
    upload_first: "Upload your first asset",
    items_available: "items available",
    upload_assets: "Upload assets",
    open_library: "Open Media Library",
    library: "Library",
    error: {
      api_unavailable: "Framework API not available",
      fetch_failed: "Failed to fetch media",
      api_not_initialized: "Framework API not initialized",
      upload_failed: "Upload failed"
    }
  },
  editor: {
    add_element_btn: "Add Block",
    block_vault: "Block Library",
    vault_desc: "Select a block to add to your page",
    tab_standard_blocks: "Standard Blocks",
    tab_section_library: "Section Templates",
    no_blocks: "No blocks added yet",
    add_first_block: "Add Your First Block",
    layout_variant: "Layout Style",
    tab_content: "Content",
    tab_style: "Style",
    manage_library: "Manage Library",
    import_json: "Import JSON",
    core_tag: "Core",
    insert_btn: "Insert",
    no_content_defined: "No content defined",
    save_template_tooltip: "Save as Template",
    use_section_tooltip: "Use this section",
    export_json_tooltip: "Export as JSON",
    delete_template_confirm: "Delete this template?",
    library_empty: "Library Empty",
    library_empty_hint: "Save blocks to build your design library",
    template_name_prompt: "Enter a name for this template:",
    template_saved: "Template saved successfully!",
    template_imported: "Template imported successfully!",
    template_import_invalid: "Invalid template file",
    drag_to_reorder: "Click to configure block"
  },
  settings: {
    tabs: {
      general: "General Settings",
      content: "Content & Slugs"
    },
    posts_per_page: {
      label: "Posts Per Page"
    },
    postsPrefix: {
      label: "Posts URL Prefix",
      description: "Define the prefix for all blog posts (e.g., /blog or /posts)"
    },
    pagesPrefix: {
      label: "Pages URL Prefix",
      description: "Optional prefix for pages"
    },
    tagsPrefix: {
      label: "Tags URL Prefix",
      description: "URL prefix for tag archive pages (e.g., /tags)"
    },
    categoriesPrefix: {
      label: "Categories URL Prefix",
      description: "URL prefix for category archive pages (e.g., /categories)"
    },
    default_post_status: {
      label: "Default Post Status"
    },
    enable_drafts: {
      label: "Enable Drafts by Default"
    },
    auto_generate_excerpts: {
      label: "Auto-generate Excerpts"
    }
  },
  blocks: {
    hero: {
      name: "Hero Section",
      title: "Headline",
      title_ph: "Enter headline...",
      subtitle: "Small Text",
      subtitle_ph: "Describe your mission...",
      visual: "Media Asset",
      media_label: "Background Image"
    },
    "text-block": {
      name: "Text Content"
    }
  }
};

// plugins/cms/settings.ts
var getSettingsSchema = (t) => ({
  tabs: [
    { id: "general", label: t("settings.tabs.general"), icon: "Settings" },
    { id: "content", label: t("settings.tabs.content"), icon: "FileText" }
  ],
  fields: [
    {
      name: "posts_per_page",
      type: "number",
      label: t("settings.posts_per_page.label"),
      defaultValue: 10,
      tab: "general"
    },
    {
      name: "postsPrefix",
      type: "text",
      label: t("settings.postsPrefix.label"),
      defaultValue: "/posts",
      description: t("settings.postsPrefix.description"),
      tab: "content"
    },
    {
      name: "pagesPrefix",
      type: "text",
      label: t("settings.pagesPrefix.label"),
      defaultValue: "",
      description: t("settings.pagesPrefix.description"),
      tab: "content"
    },
    {
      name: "tagsPrefix",
      type: "text",
      label: t("settings.tagsPrefix.label"),
      defaultValue: "/tags",
      description: t("settings.tagsPrefix.description"),
      tab: "content"
    },
    {
      name: "categoriesPrefix",
      type: "text",
      label: t("settings.categoriesPrefix.label"),
      defaultValue: "/categories",
      description: t("settings.categoriesPrefix.description"),
      tab: "content"
    },
    {
      name: "default_post_status",
      type: "select",
      label: t("settings.default_post_status.label"),
      defaultValue: "draft",
      options: [
        { label: "Draft", value: "draft" },
        { label: "Published", value: "published" }
      ],
      tab: "content"
    },
    {
      name: "enable_drafts",
      label: t("settings.enable_drafts.label"),
      type: "boolean",
      defaultValue: true,
      tab: "content"
    },
    {
      name: "auto_generate_excerpts",
      label: t("settings.auto_generate_excerpts.label"),
      type: "boolean",
      defaultValue: true,
      tab: "content"
    }
  ],
  /**
   * Custom Validation Logic (Server-side)
   */
  validate: async (settings, context) => {
    const errors = {};
    if (settings.posts_per_page > 100) {
      errors.posts_per_page = "Posts per page cannot exceed 100 for performance reasons.";
    }
    return Object.keys(errors).length > 0 ? errors : null;
  },
  /**
   * Custom Logic after saving (Server-side)
   */
  onSave: async (oldSettings, newSettings, context) => {
  }
});

// plugins/cms/api.ts
var registerRoutes = (context) => {
  context.api.get("/status", async (req, res) => {
    return res.json({ status: "ok", version: "1.5.2" });
  });
  context.api.get("/stats", async (req, res) => {
    try {
      const postsCount = await context.db.count("posts");
      const pagesCount = await context.db.count("pages");
      const mediaCount = await context.db.count("media");
      return res.json({
        postsCount,
        pagesCount,
        mediaCount,
        postsTrend: 12,
        pagesTrend: 5,
        mediaTrend: 24
      });
    } catch (e) {
      return res.json({ postsCount: 0, pagesCount: 0, mediaCount: 0, postsTrend: 0, pagesTrend: 0, mediaTrend: 0 });
    }
  });
  context.api.get("/posts", async (req, res) => {
    try {
      const settings = await context.settings.get();
      const limit = settings.posts_per_page || 10;
      const prefix = settings.postsPrefix || "/posts";
      const posts = await context.db.find("posts", {
        limit: Number(limit),
        sort: "-createdAt"
      });
      const enrichedPosts = posts.map((post) => ({
        ...post,
        url: `${prefix}/${post.slug}`.replace(/\/+/g, "/")
      }));
      return res.json(enrichedPosts);
    } catch (e) {
      return res.json([]);
    }
  });
  context.api.get("/navigation/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const menu = await context.db.findOne("navigation", { slug });
      if (!menu) {
        return res.status(404).json({ error: "Navigation menu not found" });
      }
      return res.json(menu);
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  });
  context.api.get("/navigation", async (_req, res) => {
    try {
      const menus = await context.db.find("navigation", { sort: "-updatedAt" });
      return res.json(menus || []);
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  });
};

// plugins/cms/hooks/posts.ts
function extractTextFromContent(content) {
  if (!content) return "";
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content.map((block) => {
    if (!block) return "";
    if (typeof block === "string") return block;
    if (block.content && typeof block.content === "string") return block.content;
    if (block.text && typeof block.text === "string") return block.text;
    if (Array.isArray(block.children)) {
      return block.children.map((child) => child && typeof child.text === "string" ? child.text : "").join(" ");
    }
    return "";
  }).filter(Boolean).join(" ");
}
function applyPostDefaultsAndExcerpt(data, settings) {
  const enableDrafts = settings?.enable_drafts !== false;
  const defaultStatus = settings?.default_post_status || "draft";
  const autoGenerateExcerpts = settings?.auto_generate_excerpts !== false;
  if (!enableDrafts) {
    data.status = "published";
  } else if (!data.status) {
    data.status = defaultStatus;
  }
  if (autoGenerateExcerpts && (!data.excerpt || String(data.excerpt).trim() === "") && data.content) {
    try {
      const fullText = extractTextFromContent(data.content).trim();
      if (fullText) {
        const truncated = fullText.length > 160 ? `${fullText.substring(0, 160)}...` : fullText;
        data.excerpt = truncated;
        console.log(`[CMS] Auto-generated excerpt for: ${data.title}`);
      }
    } catch (e) {
      console.error("[CMS] Failed to generate excerpt");
    }
  }
  return data;
}

// plugins/cms/index.ts
var onInit = async (context) => {
  context.i18n.registerTranslations("en", en_default);
  context.settings.register(getSettingsSchema((key) => context.t(key)));
  context.collections.register(Pages_default);
  context.collections.register(Posts_default);
  context.collections.register(Categories_default);
  context.collections.register(Tags_default);
  context.collections.register(Templates_default);
  context.collections.register(Navigation_default);
  registerRoutes(context);
  context.hooks.on("collection:posts:beforeSave", async (data) => {
    const settings = await context.settings.get();
    return applyPostDefaultsAndExcerpt(data, settings);
  });
};
var onEnable = async (context) => {
  console.log("CMS Plugin Enabled");
};
var index_default = (0, import_sdk.definePlugin)({
  onInit,
  onEnable,
  publicAPI: (context) => ({
    getSettings: () => context.settings.get()
  })
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onEnable,
  onInit
});
//# sourceMappingURL=index.js.map
